<?php require 'auth.php'; ?>
<?php
require 'db.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin', 'staff', 'tutor'])) {
    die("Access denied");
}

$trainee_id = isset($_GET['id']) ? strtoupper(trim($_GET['id'])) : '';
if ($trainee_id === '') {
    die("No trainee ID provided.");
}

$stmt = $pdo->prepare("
  SELECT t.*, m.module_name
  FROM trainees t
  LEFT JOIN modules m ON t.module_id = m.module_id
  WHERE t.trainee_id = ?
");
$stmt->execute([$trainee_id]);
$trainee = $stmt->fetch();

if (!$trainee) {
    die("Trainee not found.");
}

$assignmentStmt = $pdo->prepare("
  SELECT ta.id AS assignment_id, at.type_name, ta.assigned_date, ta.due_date, ta.status,
         s.score_percent, s.feedback_text
  FROM trainee_assignments ta
  LEFT JOIN assignment_types at ON ta.type_id = at.type_id
  LEFT JOIN assignment_submissions s ON ta.id = s.assignment_id AND ta.trainee_id = s.trainee_id
  WHERE ta.trainee_id = ?
  ORDER BY ta.due_date ASC
");
$assignmentStmt->execute([$trainee_id]);
$assignments = $assignmentStmt->fetchAll();

$feedbackStmt = $pdo->prepare("
  SELECT tf.feedback_date, tf.notes, tf.alert_flag, tu.first_name AS tutor_first, tu.surname AS tutor_surname
  FROM tutor_feedback tf
  JOIN tutors tu ON tf.tutor_id = tu.tutor_id
  WHERE tf.trainee_id = ?
  ORDER BY tf.feedback_date DESC
  LIMIT 3
");
$feedbackStmt->execute([$trainee_id]);
$feedbackEntries = $feedbackStmt->fetchAll();

$logStmt = $pdo->prepare("
  SELECT action_type, description, timestamp, performed_by
  FROM trainee_logs
  WHERE trainee_id = ?
  ORDER BY timestamp DESC
  LIMIT 5
");
$logStmt->execute([$trainee_id]);
$logs = $logStmt->fetchAll();

$groupStmt = $pdo->prepare("
  SELECT sg.group_id, sg.module_number, sg.module_title, sg.group_option
  FROM supervision_group_trainees sgt
  JOIN supervision_groups sg ON sgt.group_id = sg.group_id
  WHERE sgt.trainee_id = ?
  LIMIT 1
");
$groupStmt->execute([$trainee_id]);
$group = $groupStmt->fetch();

$supervisorStmt = $pdo->prepare("
  SELECT first_name, surname, email
  FROM supervisors
  WHERE supervisor_id = ?
");
$supervisorStmt->execute([$trainee['supervisor_id']]);
$supervisor = $supervisorStmt->fetch();

$photoPath = '';
if (!empty($trainee['profile_image']) && file_exists($trainee['profile_image'])) {
    $photoPath = $trainee['profile_image'];
}
$percentStmt = $pdo->prepare("
  SELECT s.session_type,
         COUNT(*) AS total,
         SUM(CASE WHEN a.attended = 1 THEN 1 ELSE 0 END) AS attended
  FROM supervision_sessions s
  JOIN supervision_session_trainees st ON s.session_id = st.session_id
  LEFT JOIN supervision_attendance a ON s.session_id = a.session_id AND a.trainee_id = ?
  WHERE st.trainee_id = ? AND s.session_date <= CURDATE()
  GROUP BY s.session_type
");
$percentStmt->execute([$trainee_id, $trainee_id]);
$percentData = $percentStmt->fetchAll(PDO::FETCH_ASSOC);

$percentIndividual = 0;
$percentGroup = 0;
foreach ($percentData as $row) {
    if ($row['session_type'] === 'individual') {
        $percentIndividual = $row['total'] ? round(($row['attended'] / $row['total']) * 100) : 0;
    }
    if ($row['session_type'] === 'group') {
        $percentGroup = $row['total'] ? round(($row['attended'] / $row['total']) * 100) : 0;
    }
}

function getStatusFlag($percent) {
    if ($percent >= 80) return ['flag' => 'green', 'label' => 'Doing Well'];
    if ($percent >= 60) return ['flag' => 'amber', 'label' => 'Needs Monitoring'];
    return ['flag' => 'red', 'label' => 'Failing'];
}

$individualStatus = getStatusFlag($percentIndividual);
$groupStatus = getStatusFlag($percentGroup);

$hasFailed = false;
foreach ($assignments as $a) {
    if ($a['score_percent'] !== null && $a['score_percent'] < 50) {
        $hasFailed = true;
        break;
    }
}
$assignmentFlag = $hasFailed ? 'red' : 'green';
$assignmentLabel = $hasFailed ? 'Failed Assignment(s)' : 'All Passed';

$progressionStmt = $pdo->prepare("
  SELECT h.changed_at, c.course_name,
         m_from.module_name AS module_from,
         m_to.module_name AS module_to,
         h.changed_by
  FROM trainees_history h
  JOIN trainees t ON h.trainee_id = t.trainee_id
  JOIN courses c ON t.course_id = c.course_id
  LEFT JOIN modules m_from ON h.previous_module_id = m_from.module_id
  LEFT JOIN modules m_to ON h.new_module_id = m_to.module_id
  WHERE h.trainee_id = ?
  ORDER BY h.changed_at DESC
");
$progressionStmt->execute([$trainee_id]);
$progressionHistory = $progressionStmt->fetchAll();

$finalCourseName = null;
if (!empty($trainee['course_id'])) {
    $courseLookup = $pdo->prepare("SELECT course_name FROM courses WHERE course_id = ?");
    $courseLookup->execute([$trainee['course_id']]);
    $finalCourseName = $courseLookup->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Trainee</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .profile-box, .section-box {
      background: #f9f9f9;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 30px;
      border: 1px solid #ccc;
    }
    .profile-photo img {
      max-width: 120px;
      border-radius: 6px;
      margin-bottom: 10px;
    }
    .profile-field {
      margin-bottom: 10px;
    }
    .btn {
      padding: 6px 12px;
      background-color: #6a1b9a;
      color: white;
      border-radius: 4px;
      text-decoration: none;
      font-size: 14px;
      margin-right: 10px;
    }
    .btn:hover {
      background-color: #4a148c;
    }
    .message.success {
      color: green;
      font-weight: bold;
    }
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="dashboard-wrapper">
  <?php include 'sidebar.php'; ?>
  <div class="main-content">
    <h2>View Trainee</h2>

    <div class="profile-box">
      <h3><?= htmlspecialchars($trainee['first_name'] . ' ' . $trainee['surname']) ?></h3>

      <div class="profile-photo">
        <?php if ($photoPath): ?>
          <img src="<?= htmlspecialchars($photoPath) ?>" alt="Trainee Photo">
        <?php else: ?>
          <em>No photo available.</em>
        <?php endif; ?>
      </div>

      <div style="display: flex; flex-wrap: wrap; gap: 40px;">
        <div style="flex: 1; min-width: 300px;">
          <div class="profile-field"><strong>Trainee ID:</strong> <?= htmlspecialchars($trainee['trainee_id']) ?></div>
          <div class="profile-field"><strong>MDX ID:</strong> <?= htmlspecialchars($trainee['mdx_id']) ?></div>
          <div class="profile-field"><strong>Email:</strong> <?= htmlspecialchars($trainee['email']) ?></div>
          <div class="profile-field"><strong>Personal Email:</strong> <?= htmlspecialchars($trainee['personal_email'] ?? '—') ?></div>
          <div class="profile-field"><strong>Date of Birth:</strong> <?= htmlspecialchars($trainee['date_of_birth']) ?></div>
          <div class="profile-field"><strong>Disability Status:</strong> <?= htmlspecialchars($trainee['disability_status']) ?></div>
          <?php if ($trainee['disability_status'] === 'Yes'): ?>
            <div class="profile-field"><strong>Disability Type:</strong> <?= htmlspecialchars($trainee['disability_type']) ?></div>
          <?php endif; ?>
          <div class="profile-field"><strong>Town/City:</strong> <?= htmlspecialchars($trainee['town_city']) ?></div>
        </div>

        <div style="flex: 1; min-width: 300px;">
          <div class="profile-field"><strong>Postcode:</strong> <?= htmlspecialchars($trainee['postcode']) ?></div>
          <div class="profile-field"><strong>Telephone:</strong> <?= htmlspecialchars($trainee['telephone']) ?></div>
          <div class="profile-field"><strong>Emergency Contact Name:</strong> <?= htmlspecialchars($trainee['emergency_contact_name'] ?? '—') ?></div>
          <div class="profile-field"><strong>Emergency Contact Number:</strong> <?= htmlspecialchars($trainee['emergency_contact_number'] ?? '—') ?></div>
          <div class="profile-field"><strong>Address:</strong> <?= htmlspecialchars($trainee['address_line1']) ?></div>
          <div class="profile-field"><strong>Enrolment Date:</strong>
            <?php
              if (!empty($trainee['start_date']) && $trainee['start_date'] !== '0000-00-00') {
                echo date('d F Y', strtotime($trainee['start_date']));
              } else {
                echo "Not available";
              }
            ?>
          </div>
          <div class="profile-field"><strong>DBS Status:</strong> <?= htmlspecialchars($trainee['dbs_status'] ?? '—') ?></div>
          <div class="profile-field"><strong>DBS Issue Date:</strong> <?= htmlspecialchars($trainee['dbs_issue_date'] ?? '—') ?></div>
          <div class="profile-field"><strong>DBS Expiry Date:</strong> <?= htmlspecialchars($trainee['dbs_expiry_date'] ?? '—') ?></div>
          <div class="profile-field"><strong>DBS Reference Number:</strong> <?= htmlspecialchars($trainee['dbs_reference_number'] ?? '—') ?></div>
          <div class="profile-field"><strong>DBS Update Service:</strong> <?= htmlspecialchars($trainee['dbs_update_service'] ?? '—') ?></div>
        </div>
      </div>

      <?php if (in_array($_SESSION['role'], ['superuser', 'admin'])): ?>
        <form method="post" action="reset_trainee_password.php" style="margin-top: 30px;">
          <input type="hidden" name="user_id" value="<?= htmlspecialchars($trainee['user_id']) ?>">
          <input type="hidden" name="trainee_id" value="<?= htmlspecialchars($trainee['trainee_id']) ?>">
          <label for="new_password"><strong>Set New Password:</strong></label>
          <input
            type="password"
            name="new_password"
            id="new_password"
            required
            pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$"
            title="Password must be at least 8 characters long and include uppercase, lowercase, number, and special character."
            style="width: 100%; padding: 8px; margin-top: 8px;"
          >
          <button type="submit" class="btn" style="margin-top: 10px;">Update Password</button>
        </form>
      <?php endif; ?>

      <?php if (isset($_GET['reset'])): ?>
        <div class="message success" style="margin-top: 15px;">Password successfully updated.</div>
      <?php endif; ?>
            <hr>
      <div class="profile-field"><strong>Assigned Course:</strong> <?= htmlspecialchars($finalCourseName ?? '—') ?></div>
      <div class="profile-field"><strong>Assigned Module:</strong> <?= htmlspecialchars($trainee['module_name'] ?? '—') ?></div>
    </div>

    <div class="attendance-banner">
      <div class="attendance-column">
        <h4>
          <a href="view_supervision_attendance.php?trainee_id=<?= urlencode($trainee_id) ?>" style="color:#4a148c; text-decoration:none;">
            Individual Supervision Attendance
          </a>
        </h4>
        <p>
          <a href="view_supervision_attendance.php?trainee_id=<?= urlencode($trainee_id) ?>" style="color:#6a1b9a; text-decoration:none;">
            <?= $percentIndividual ?>%
          </a>
        </p>
      </div>
      <div class="attendance-column">
        <h4>
          <a href="view_supervision_attendance.php?trainee_id=<?= urlencode($trainee_id) ?>" style="color:#4a148c; text-decoration:none;">
            Group Supervision Attendance
          </a>
        </h4>
        <p>
          <a href="view_supervision_attendance.php?trainee_id=<?= urlencode($trainee_id) ?>" style="color:#6a1b9a; text-decoration:none;">
            <?= $percentGroup ?>%
          </a>
        </p>
      </div>
      <p class="disclaimer">
        Attendance percentages reflect sessions offered to date. Future sessions are excluded.
      </p>
    </div>

    <div class="section-box">
      <h3>Recent Feedback</h3>
      <?php if ($feedbackEntries): ?>
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Tutor</th>
              <th>Alert</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($feedbackEntries as $f): ?>
              <tr>
                <td><?= htmlspecialchars($f['feedback_date']) ?></td>
                <td><?= htmlspecialchars($f['tutor_first'] . ' ' . $f['tutor_surname']) ?></td>
                <td><?= $f['alert_flag'] === 'Yes' ? '⚠️ Yes' : 'No' ?></td>
                <td><?= nl2br(htmlspecialchars($f['notes'])) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <p>No feedback entries found.</p>
      <?php endif; ?>
    </div>
        <div class="section-box">
      <h3>Recent Logs</h3>
      <?php if ($logs): ?>
        <table>
          <thead>
            <tr>
              <th>Timestamp</th>
              <th>Action</th>
              <th>Description</th>
              <th>Performed By</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($logs as $log): ?>
              <tr>
                <td><?= htmlspecialchars($log['timestamp']) ?></td>
                <td><?= htmlspecialchars($log['action_type']) ?></td>
                <td>
                  <?php
                    echo htmlspecialchars($log['description']);
                    if ($log['action_type'] === 'Module Progression') {
                      if (preg_match('/ID (\d+)/', $log['description'], $matches)) {
                        $modId = $matches[1];
                        $modStmt = $pdo->prepare("SELECT module_name FROM modules WHERE module_id = ?");
                        $modStmt->execute([$modId]);
                        $modName = $modStmt->fetchColumn();
                        if ($modName) {
                          echo ' (' . htmlspecialchars($modName) . ')';
                        }
                      }
                    }
                  ?>
                </td>
                <td><?= htmlspecialchars($log['performed_by']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <p>No log entries found.</p>
      <?php endif; ?>
    </div>

    <div class="section-box">
      <h3>Supervision Group</h3>
      <?php if ($group): ?>
        <p><strong>Module:</strong> <?= htmlspecialchars($group['module_number']) ?> — <?= htmlspecialchars($group['module_title']) ?></p>
        <p><strong>Option:</strong> <?= htmlspecialchars($group['group_option']) ?></p>
      <?php else: ?>
        <p>No supervision group assigned.</p>
      <?php endif; ?>
    </div>

    <div class="section-box">
      <h3>Supervisor</h3>
      <?php if ($supervisor): ?>
        <p><strong>Name:</strong> <?= htmlspecialchars($supervisor['first_name'] . ' ' . $supervisor['surname']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($supervisor['email']) ?></p>
      <?php else: ?>
        <p>No supervisor assigned.</p>
      <?php endif; ?>
    </div>

    <div class="section-box">
      <a href="edit_trainee.php?trainee_id=<?= urlencode($trainee_id) ?>" class="btn">Edit Trainee</a>
    </div>

  </div>
</div>
</body>
</html>