<?php require 'auth.php'; ?>
<?php
require 'db.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin', 'staff'])) {
  die("Access denied.");
}

// Fetch all tutors with account status
$stmt = $pdo->prepare("
  SELECT tu.*, 
         u.account_locked, u.failed_attempts
  FROM tutors tu
  LEFT JOIN users u ON tu.tutor_id = u.user_id
  ORDER BY tu.surname
");
$stmt->execute();
$tutors = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch assigned courses
$courseStmt = $pdo->prepare("
  SELECT tc.tutor_id, c.course_name
  FROM tutor_courses tc
  JOIN courses c ON tc.course_id = c.course_id
");
$courseStmt->execute();
$courseMap = [];
foreach ($courseStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
  $courseMap[$row['tutor_id']][] = $row['course_name'];
}

// Fetch assigned modules
$moduleStmt = $pdo->prepare("
  SELECT tm.tutor_id, m.module_name
  FROM tutor_modules tm
  JOIN modules m ON tm.module_id = m.module_id
");
$moduleStmt->execute();
$moduleMap = [];
foreach ($moduleStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
  $moduleMap[$row['tutor_id']][] = $row['module_name'];
}

// CSV export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="tutor_records.csv"');
  $out = fopen('php://output', 'w');
  fputcsv($out, [
    'ID', 'Name', 'Email', 'Telephone', 'Start Date', 'Archived',
    'DOB', 'Disability Status', 'Disability Type', 'Town/City', 'Postcode',
    'Address Line 1', 'Job Title', 'Role', 'DBS Status', 'DBS Date',
    'DBS Reference', 'DBS Update Service', 'Account Locked', 'Failed Attempts',
    'Assigned Courses', 'Assigned Modules'
  ]);
  foreach ($tutors as $t) {
    fputcsv($out, [
      $t['tutor_id'],
      $t['first_name'] . ' ' . $t['surname'],
      $t['email'],
      $t['telephone'],
      $t['start_date'],
      $t['is_archived'] ? 'Yes' : 'No',
      $t['date_of_birth'],
      $t['disability_status'],
      $t['disability_type'],
      $t['town_city'],
      $t['postcode'],
      $t['address_line1'],
      $t['job_title'],
      $t['role'],
      $t['dbs_status'],
      $t['dbs_date'],
      $t['dbs_reference'],
      $t['dbs_update_service'] ? 'Yes' : 'No',
      $t['account_locked'] ? 'Yes' : 'No',
      $t['failed_attempts'],
      implode(', ', $courseMap[$t['tutor_id']] ?? []),
      implode(', ', $moduleMap[$t['tutor_id']] ?? [])
    ]);
  }
  fclose($out);
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>All Tutor Records</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .main-content { padding: 40px; max-width: 1600px; margin: auto; }
    .tutor-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    .tutor-table th, .tutor-table td {
      padding: 10px;
      border-bottom: 1px solid #ccc;
      vertical-align: top;
    }
    .tutor-table th {
      background-color: #6a1b9a;
      color: white;
    }
    .btn {
      display: inline-block;
      padding: 8px 16px;
      background-color: #6a1b9a;
      color: white;
      text-decoration: none;
      border-radius: 4px;
      font-weight: bold;
      margin-bottom: 20px;
    }
    .btn:hover {
      background-color: #4a148c;
    }
    .profile-img {
      max-width: 80px;
      max-height: 80px;
      border-radius: 4px;
    }
    .no-results {
      font-style: italic;
      color: #777;
    }
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="dashboard-wrapper">
  <?php include 'sidebar.php'; ?>
  <div class="main-content">
    <h2>All Tutor Records</h2>

    <a href="?export=csv" class="btn">Export CSV</a>

    <?php if (count($tutors) === 0): ?>
      <p class="no-results">No tutors found.</p>
    <?php else: ?>
      <table class="tutor-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Telephone</th>
            <th>Start Date</th>
            <th>Archived</th>
            <th>DOB</th>
            <th>Disability</th>
            <th>Location</th>
            <th>Address</th>
            <th>Profile</th>
            <th>Job Title</th>
            <th>Role</th>
            <th>DBS Status</th>
            <th>DBS Date</th>
            <th>DBS Reference</th>
            <th>DBS Update</th>
            <th>Account Locked</th>
            <th>Failed Attempts</th>
            <th>Assigned Courses</th>
            <th>Assigned Modules</th>
            <th>View</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($tutors as $t): ?>
            <tr>
              <td><?= htmlspecialchars($t['tutor_id']) ?></td>
              <td><?= htmlspecialchars($t['first_name'] . ' ' . $t['surname']) ?></td>
              <td><?= htmlspecialchars($t['email']) ?></td>
              <td><?= htmlspecialchars($t['telephone']) ?></td>
              <td><?= htmlspecialchars($t['start_date']) ?></td>
              <td><?= $t['is_archived'] ? 'Yes' : 'No' ?></td>
              <td><?= htmlspecialchars($t['date_of_birth']) ?></td>
              <td>
                <?= htmlspecialchars($t['disability_status']) ?><br>
                <?= htmlspecialchars($t['disability_type']) ?>
              </td>
              <td>
                <?= htmlspecialchars($t['town_city']) ?><br>
                <?= htmlspecialchars($t['postcode']) ?>
              </td>
              <td><?= htmlspecialchars($t['address_line1']) ?></td>
              <td>
                <?php if (!empty($t['profile_image']) && file_exists('uploads/' . basename($t['profile_image']))): ?>
                  <img src="<?= 'uploads/' . htmlspecialchars(basename($t['profile_image'])) ?>" class="profile-img" alt="Profile">
                <?php else: ?>
                  —
                <?php endif; ?>
              </td>
              <td><?= htmlspecialchars($t['job_title']) ?></td>
              <td><?= htmlspecialchars($t['role']) ?></td>
              <td><?= htmlspecialchars($t['dbs_status'] ?? '—') ?></td>
              <td><?= htmlspecialchars($t['dbs_date'] ?? '—') ?></td>
              <td><?= htmlspecialchars($t['dbs_reference'] ?? '—') ?></td>
              <td><?= isset($t['dbs_update_service']) && $t['dbs_update_service'] ? 'Yes' : 'No' ?></td>
              <td><?= $t['account_locked'] ? 'Yes' : 'No' ?></td>
              <td><?= htmlspecialchars($t['failed_attempts']) ?></td>
              <td>
                <?= isset($courseMap[$t['tutor_id']]) ? implode(', ', array_map('htmlspecialchars', $courseMap[$t['tutor_id']])) : '—' ?>
              </td>
              <td>
                <?= isset($moduleMap[$t['tutor_id']]) ? implode(', ', array_map('htmlspecialchars', $moduleMap[$t['tutor_id']])) : '—' ?>
              </td>
              <td>
                <a href="view_tutor.php?id=<?= $t['tutor_id'] ?>" class="btn" target="_blank">View</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
</body>
</html>