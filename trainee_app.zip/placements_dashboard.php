<?php
require_once 'auth.php';
require_once 'db.php';
include 'header.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin', 'staff'])) {
  die("Access denied.");
}

$nameFilter = $_GET['name'] ?? '';
$placementFilter = $_GET['placement'] ?? '';

$traineeQuery = "
  SELECT trainee_id, CONCAT(first_name, ' ', surname) AS full_name
  FROM trainees
  WHERE is_archived = 0
";
$params = [];

if (!empty($nameFilter)) {
  $traineeQuery .= " AND (first_name LIKE ? OR surname LIKE ?)";
  $params[] = "%$nameFilter%";
  $params[] = "%$nameFilter%";
}

if (!empty($placementFilter)) {
  $traineeQuery .= " AND trainee_id IN (
    SELECT trainee_id FROM trainee_placements tp
    JOIN placement_settings ps ON tp.placement_id = ps.id
    WHERE ps.name LIKE ?
  )";
  $params[] = "%$placementFilter%";
}

$traineeQuery .= " ORDER BY surname";
$stmt = $pdo->prepare($traineeQuery);
$stmt->execute($params);
$trainees = $stmt->fetchAll();

// Fetch placements per trainee
$placement_map = [];
foreach ($trainees as $t) {
  $stmt = $pdo->prepare("
    SELECT ps.name
    FROM trainee_placements tp
    JOIN placement_settings ps ON tp.placement_id = ps.id
    WHERE tp.trainee_id = ?
    ORDER BY tp.start_date
    LIMIT 3
  ");
  $stmt->execute([$t['trainee_id']]);
  $placement_map[$t['trainee_id']] = $stmt->fetchAll(PDO::FETCH_COLUMN);
}
?>

<div class="dashboard-wrapper">
  <?php include 'sidebar.php'; ?>
  <div class="main-content">
    <h2>Placement Overview</h2>

    <div class="top-actions">
      <div class="action-buttons">
        <a href="assign_placement.php" class="btn-sm btn-active">
          <i class="fas fa-plus"></i> Add Placement
        </a>
        <a href="reassign_placement.php" class="btn-sm btn-default">
          <i class="fas fa-sync"></i> Reassign Placement
        </a>
      </div>
    </div>

    <form method="get" class="search-form">
      <div class="search-grid">
        <input type="text" name="name" placeholder="Search by name" value="<?= htmlspecialchars($nameFilter) ?>">
        <input type="text" name="placement" placeholder="Search by placement" value="<?= htmlspecialchars($placementFilter) ?>">
        <button type="submit" class="btn-sm btn-default">Search</button>
        <a href="placements_dashboard.php" class="btn-sm btn-default">Reset</a>
      </div>
    </form>

    <table class="trainee-table">
      <thead>
        <tr>
          <th>Trainee</th>
          <th>Placement 1</th>
          <th>Placement 2</th>
          <th>Placement 3</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($trainees as $t): ?>
          <tr>
            <td>
              <a href="view_trainee.php?id=<?= $t['trainee_id'] ?>">
                <?= htmlspecialchars($t['full_name']) ?>
              </a>
            </td>
            <?php
              $placements = $placement_map[$t['trainee_id']] ?? [];
              for ($i = 0; $i < 3; $i++):
            ?>
              <td><?= htmlspecialchars($placements[$i] ?? '') ?></td>
            <?php endfor; ?>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>