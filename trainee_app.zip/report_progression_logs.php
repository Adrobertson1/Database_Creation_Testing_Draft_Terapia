<?php require 'auth.php'; ?>
<?php
require 'db.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin', 'staff'])) {
  die("Access denied.");
}

// Fetch progression logs
$stmt = $pdo->prepare("
  SELECT h.trainee_id, t.first_name, t.surname, c.course_name,
         m_from.module_name AS module_from,
         m_to.module_name AS module_to,
         h.changed_at, h.changed_by
  FROM trainees_history h
  JOIN trainees t ON h.trainee_id = t.trainee_id
  JOIN courses c ON t.course_id = c.course_id
  LEFT JOIN modules m_from ON h.previous_module_id = m_from.module_id
  LEFT JOIN modules m_to ON h.new_module_id = m_to.module_id
  ORDER BY h.changed_at DESC
");
$stmt->execute();
$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

// CSV export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename=trainee_progression_logs.csv');
  header('Pragma: no-cache');
  header('Expires: 0');

  $out = fopen('php://output', 'w');
  fputcsv($out, ['Date', 'Trainee', 'Course', 'Module From', 'Module To', 'Changed By']);
  foreach ($records as $r) {
    fputcsv($out, [
      date('d M Y', strtotime($r['changed_at'])),
      $r['first_name'] . ' ' . $r['surname'],
      $r['course_name'],
      $r['module_from'] ?? '—',
      $r['module_to'] ?? '—',
      $r['changed_by']
    ]);
  }
  fclose($out);
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Trainee Progression Logs</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .main-content { padding: 40px; max-width: 1200px; margin: auto; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { padding: 10px; border: 1px solid #ccc; text-align: left; }
    th { background-color: #6a1b9a; color: white; }
    .btn {
      display: inline-block;
      padding: 10px 20px;
      background-color: #6a1b9a;
      color: white;
      text-decoration: none;
      border-radius: 4px;
      font-weight: bold;
      margin-bottom: 20px;
    }
    .btn:hover { background-color: #4a148c; }
    .name-link {
      color: #6a1b9a;
      font-weight: bold;
      text-decoration: none;
    }
    .name-link:hover {
      text-decoration: underline;
    }
    .no-results {
      font-style: italic;
      color: #777;
    }
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="dashboard-wrapper">
<?php include 'sidebar.php'; ?>
<div class="main-content">
  <h2>Trainee Progression Logs</h2>
  <a href="report_progression_logs.php?export=csv" class="btn">Export CSV</a>

  <?php if (count($records) === 0): ?>
    <p class="no-results">No progression records found.</p>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>Date</th>
          <th>Trainee</th>
          <th>Course</th>
          <th>Module From</th>
          <th>Module To</th>
          <th>Changed By</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($records as $r): ?>
          <tr>
            <td><?= date('d M Y', strtotime($r['changed_at'])) ?></td>
            <td>
              <a href="view_trainee.php?id=<?= urlencode($r['trainee_id']) ?>" class="name-link" target="_blank">
                <?= htmlspecialchars($r['first_name'] . ' ' . $r['surname']) ?>
              </a>
            </td>
            <td><?= htmlspecialchars($r['course_name']) ?></td>
            <td><?= htmlspecialchars($r['module_from'] ?? '—') ?></td>
            <td><?= htmlspecialchars($r['module_to'] ?? '—') ?></td>
            <td><?= htmlspecialchars($r['changed_by']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
</div>
</body>
</html>