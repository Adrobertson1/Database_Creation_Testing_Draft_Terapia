<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

require 'db.php';
$config = require __DIR__ . '/config.php';
require_once __DIR__ . '/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$error = '';
$success = '';

function generateToken($length = 64) {
    return bin2hex(random_bytes($length / 2));
}

function storeResetToken($pdo, $user_id, $email, $role, $token) {
    $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));

    try {
        $stmt = $pdo->prepare("
            INSERT INTO password_resets (
                user_id, email, role, token, requested_at, expires_at, ip_address
            ) VALUES (
                ?, ?, ?, ?, NOW(), CAST(? AS DATETIME), ?
            )
        ");
        $stmt->execute([
            $user_id,
            $email,
            $role,
            $token,
            $expires_at,
            $_SERVER['REMOTE_ADDR']
        ]);
        error_log("✅ Token stored with expiry: $expires_at");
    } catch (PDOException $e) {
        error_log("❌ Insert failed: " . $e->getMessage());
    }
}

function sendResetEmail($recipient, $token, $config) {
    $mail = new PHPMailer(true);
    try {
        $mail->SMTPDebug = 2;
        $mail->Debugoutput = 'error_log';

        $mail->isSMTP();
        $mail->Host       = $config['SMTP_HOST'];
        $mail->SMTPAuth   = true;
        $mail->Username   = $config['SMTP_USER'];
        $mail->Password   = $config['SMTP_PASS'];
        $mail->SMTPSecure = $config['SMTP_SECURE'];
        $mail->Port       = $config['SMTP_PORT'];

        $mail->setFrom($config['SMTP_USER'], 'Terapia System');
        $mail->addAddress($recipient);

        $resetLink = "{$config['RESET_URL_BASE']}/reset_password.php?token=$token";
        $mail->Subject = 'Password Reset Request';
        $mail->Body    = "Click the link below to reset your password:\n\n$resetLink";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Mailer Error: " . $mail->ErrorInfo);
        return false;
    }
}

function findUserByEmail($pdo, $email) {
    $sources = [
        ['table' => 'users',       'id' => 'user_id',       'role' => "'superuser'", 'condition' => 'is_active = 1'],
        ['table' => 'staff',       'id' => 'staff_id',      'role' => 'role',        'condition' => 'is_archived = 0'],
        ['table' => 'trainees',    'id' => 'trainee_id',    'role' => "'trainee'",   'condition' => 'is_archived = 0'],
        ['table' => 'tutors',      'id' => 'tutor_id',      'role' => "'tutor'",     'condition' => 'is_archived = 0'],
        ['table' => 'supervisors', 'id' => 'supervisor_id', 'role' => "'supervisor'",'condition' => 'is_archived = 0']
    ];

    foreach ($sources as $src) {
        $stmt = $pdo->prepare("
            SELECT {$src['id']} AS user_id, email, {$src['role']} AS role
            FROM {$src['table']}
            WHERE email = ? AND {$src['condition']}
            LIMIT 1
        ");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user) return ['source' => $src['table'], 'data' => $user];
    }

    return null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');

    if (!$email) {
        $error = "Please enter your email address.";
    } else {
        $user = findUserByEmail($pdo, $email);

        if ($user) {
            $token = generateToken();
            storeResetToken($pdo, $user['data']['user_id'], $email, $user['data']['role'], $token);

            if (sendResetEmail($email, $token, $config)) {
                $success = "A password reset link has been sent to your email.";
            } else {
                $error = "Failed to send email. Please contact support.";
            }
        } else {
            $error = "No active account found for that email.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Terapia | Request Password Reset</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background: #E6D6EC;
      color: #000;
    }
    .reset-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin-top: 60px;
    }
    .logo {
      width: 120px;
      margin-bottom: 20px;
    }
    .reset-box {
      background: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 400px;
      text-align: center;
    }
    .reset-box h2 {
      color: #850069;
      font-family: 'Josefin Sans', sans-serif;
      margin-bottom: 20px;
    }
    .reset-box label {
      display: block;
      margin-top: 15px;
      font-weight: bold;
      text-align: left;
    }
    .reset-box input {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 16px;
    }
    .reset-box button {
      margin-top: 20px;
      padding: 12px;
      background-color: #850069;
      color: white;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      width: 100%;
      font-size: 18px;
    }
    .reset-box button:hover {
      background-color: #BB9DC6;
    }
    .message.error {
      margin-top: 15px;
      color: #d32f2f;
      font-weight: bold;
    }
    .message.success {
      margin-top: 15px;
      color: #388e3c;
      font-weight: bold;
    }
    .back-link {
      margin-top: 20px;
      display: block;
      text-align: center;
      color: #850069;
      font-weight: bold;
      text-decoration: none;
    }
    .back-link:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
<div class="reset-wrapper">
  <img src="assets/logo.png" alt="Terapia Logo" class="logo">

  <div class="reset-box">
    <h2>Request Password Reset</h2>

    <?php if ($error): ?>
      <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
      <div class="message success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="post">
      <label for="email">Email Address:</label>
      <input type="email" name="email" id="email" required>

      <button type="submit">Send Reset Link</button>
    </form>

    <a href="login.php" class="back-link">← Back to Login</a>
  </div>
</div>
</body>
</html>