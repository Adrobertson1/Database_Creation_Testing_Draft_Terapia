<?php require 'auth.php'; ?>
<?php
require 'db.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin', 'staff', 'supervisor'])) {
    die("Access denied.");
}

$trainee_id = isset($_GET['trainee_id']) ? strtoupper(trim($_GET['trainee_id'])) : '';
if ($trainee_id === '') {
    die("No trainee ID provided.");
}

$user_id = $_SESSION['user_id'] ?? null;

// Handle attendance/note updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['attendance'])) {
    foreach ($_POST['attendance'] as $session_id => $attended) {
        $attendedValue = $attended === 'on' ? 1 : 0;
        $noteText = $_POST['notes'][$session_id] ?? '';

        // Fetch old values for audit
        $oldStmt = $pdo->prepare("
            SELECT attended, notes FROM supervision_attendance
            WHERE session_id = ? AND trainee_id = ?
        ");
        $oldStmt->execute([$session_id, $trainee_id]);
        $old = $oldStmt->fetch(PDO::FETCH_ASSOC) ?: ['attended' => null, 'notes' => null];

        // Update or insert attendance
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM supervision_attendance WHERE session_id = ? AND trainee_id = ?");
        $checkStmt->execute([$session_id, $trainee_id]);
        $exists = $checkStmt->fetchColumn();

        if ($exists) {
            $updateStmt = $pdo->prepare("UPDATE supervision_attendance SET attended = ?, notes = ? WHERE session_id = ? AND trainee_id = ?");
            $updateStmt->execute([$attendedValue, $noteText, $session_id, $trainee_id]);
        } else {
            $insertStmt = $pdo->prepare("INSERT INTO supervision_attendance (session_id, trainee_id, attended, notes) VALUES (?, ?, ?, ?)");
            $insertStmt->execute([$session_id, $trainee_id, $attendedValue, $noteText]);
        }

        // Audit log
        $auditStmt = $pdo->prepare("
            INSERT INTO supervision_audit_log (user_id, trainee_id, session_id, action_type, old_value, new_value)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $auditStmt->execute([
            $user_id,
            $trainee_id,
            $session_id,
            'attendance_update',
            json_encode($old),
            json_encode(['attended' => $attendedValue, 'notes' => $noteText])
        ]);
    }
}

// Fetch trainee details
$infoStmt = $pdo->prepare("
  SELECT t.first_name, t.surname, m.module_name, c.course_name
  FROM trainees t
  LEFT JOIN modules m ON t.module_id = m.module_id
  LEFT JOIN trainee_courses tc ON t.trainee_id = tc.trainee_id
  LEFT JOIN courses c ON tc.course_id = c.course_id
  WHERE t.trainee_id = ?
  LIMIT 1
");
$infoStmt->execute([$trainee_id]);
$trainee = $infoStmt->fetch();
if (!$trainee) {
    die("Trainee not found.");
}

// Attendance percentage calculations
$percentStmt = $pdo->prepare("
  SELECT s.session_type,
         COUNT(*) AS total,
         SUM(CASE WHEN a.attended = 1 THEN 1 ELSE 0 END) AS attended
  FROM supervision_sessions s
  JOIN supervision_session_trainees st ON s.session_id = st.session_id
  LEFT JOIN supervision_attendance a ON s.session_id = a.session_id AND a.trainee_id = ?
  WHERE st.trainee_id = ? AND s.session_date <= CURDATE()
  GROUP BY s.session_type
");
$percentStmt->execute([$trainee_id, $trainee_id]);
$percentData = $percentStmt->fetchAll(PDO::FETCH_ASSOC);

$individualPercent = 0;
$groupPercent = 0;
foreach ($percentData as $row) {
    if ($row['session_type'] === 'individual') {
        $individualPercent = $row['total'] ? round(($row['attended'] / $row['total']) * 100) : 0;
    }
    if ($row['session_type'] === 'group') {
        $groupPercent = $row['total'] ? round(($row['attended'] / $row['total']) * 100) : 0;
    }
}

// Handle filters
$typeFilter = $_GET['type'] ?? 'all';
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';

$whereClauses = ["st.trainee_id = ?"];
$params = [$trainee_id, $trainee_id];

if (in_array($typeFilter, ['individual', 'group'])) {
    $whereClauses[] = "s.session_type = ?";
    $params[] = $typeFilter;
}
if ($startDate) {
    $whereClauses[] = "s.session_date >= ?";
    $params[] = $startDate;
}
if ($endDate) {
    $whereClauses[] = "s.session_date <= ?";
    $params[] = $endDate;
}

$whereSQL = implode(" AND ", $whereClauses);

// Fetch sessions
$sessionStmt = $pdo->prepare("
  SELECT s.session_id, s.session_date, s.session_time, s.session_type,
         COALESCE(a.attended, 0) AS attended,
         COALESCE(a.notes, s.notes) AS notes
  FROM supervision_sessions s
  JOIN supervision_session_trainees st ON s.session_id = st.session_id
  LEFT JOIN supervision_attendance a ON s.session_id = a.session_id AND a.trainee_id = ?
  WHERE $whereSQL
  ORDER BY s.session_date ASC, s.session_time ASC
");
$sessionStmt->execute($params);
$sessions = $sessionStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Supervision Attendance for <?= htmlspecialchars($trainee['first_name'] . ' ' . $trainee['surname']) ?></title>
  <link rel="stylesheet" href="style.css">
  <style>
    .layout-wrapper { display: flex; min-height: 100vh; background: #f4f4f4; }
    .main-content { flex-grow: 1; padding: 40px; font-family: 'Inter', sans-serif; }
    h2 { color: #6a1b9a; font-family: 'Josefin Sans', sans-serif; }
    .trainee-info, .filter-box, .attendance-banner, .supervision-key {
      background: #fff; padding: 20px; border-radius: 8px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1); margin-bottom: 20px;
    }
    .trainee-info p { margin: 6px 0; }
    .attendance-banner {
      background-color: #e6d6f2; display: flex;
      justify-content: space-between; flex-wrap: wrap; align-items: center;
    }
    .attendance-column { flex: 1; min-width: 200px; text-align: center; }
    .attendance-column h4 { margin-bottom: 8px; color: #4a148c; }
    .attendance-column p { font-size: 24px; font-weight: bold; color: #6a1b9a; }
    .disclaimer { width: 100%; margin-top: 12px; font-size: 13px; color: #555; text-align: center; }
    .filter-box label { font-weight: bold; margin-right: 10px; }
    .filter-box input, .filter-box select { margin-right: 20px; padding: 6px; }
    .filter-box button {
      padding: 6px 12px; background-color: #6a1b9a; color: white;
      border: none; border-radius: 4px; cursor: pointer;
    }
    .filter-box button:hover { background-color: #4a148c; }
    .supervision-key span {
      display: inline-block; padding: 4px 10px; margin-right: 12px;
      border-radius: 4px; font-size: 14px;
    }
    .key-individual { background-color: #f3e5f5; }
    .key-group { background-color: #ede7f6; }
    table {
      width: 100%; border-collapse: collapse; background: #fff;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1); margin-top: 20px;
    }
    th, td { padding: 10px; border: 1px solid #ccc; vertical-align: middle; }
    th { background-color: #6a1b9a; color: white; }
    .individual-row { background-color: #f3e5f5; }
    .group-row { background-color: #ede7f6; }
    .btn-back, .btn-export {
      display: inline-block; margin-top: 20px; padding: 8px 14px;
      background-color: #6a1b9a; color: white; border-radius: 4px;
      text-decoration: none; margin-right: 10px;
    }
    .btn-back:hover, .btn-export:hover { background-color: #4a148c; }
    .trainee-link { font-weight: bold; color: #6a1b9a; text-decoration: none; }
    .trainee-link:hover { text-decoration: underline; }
    .attendance-form button[type="submit"] {
      margin-top: 10px; padding: 8px 14px; background-color: #6a1b9a;
      color: white; border: none; border-radius: 4px; cursor: pointer;
    }
    .attendance-form button[type="submit"]:hover { background-color: #4a148c; }
    .unlock-btn {
      padding: 6px 10px; background-color: #ccc; border: none;
      border-radius: 4px; cursor: pointer; margin-left: 10px;
    }
    .unlock-btn:hover { background-color: #bbb; }
    .notes-cell textarea {
      height: 80px; width: 100%; resize: vertical;
    }
  </style>
</head>
<body>
  <?php include 'header.php'; ?>
  <div class="layout-wrapper">
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
      <h2>
        Supervision Attendance for
      <a href="http://localhost/trainee_app/view_trainee.php?id=<?= urlencode($trainee_id) ?>" class="trainee-link">
          <?= htmlspecialchars($trainee['first_name'] . ' ' . $trainee['surname']) ?>
        </a>
      </h2>

      <div class="trainee-info">
        <p><strong>Course:</strong> <?= htmlspecialchars($trainee['course_name'] ?? '—') ?></p>
        <p><strong>Current Module:</strong> <?= htmlspecialchars($trainee['module_name'] ?? '—') ?></p>
      </div>

      <div class="attendance-banner">
        <div class="attendance-column">
          <h4>Individual Supervision Attendance</h4>
          <p><?= $individualPercent ?>%</p>
        </div>
        <div class="attendance-column">
          <h4>Group Supervision Attendance</h4>
          <p><?= $groupPercent ?>%</p>
        </div>
        <p class="disclaimer">
          Attendance percentages are based on sessions historically offered.
          Future sessions that have not yet occurred do not impact these figures.
        </p>
      </div>

      <div class="supervision-key">
        <strong>Supervision Type Key:</strong>
        <span class="key-individual">Individual Supervision</span>
        <span class="key-group">Group Supervision</span>
      </div>

      <div class="filter-box">
        <form method="get">
          <input type="hidden" name="trainee_id" value="<?= htmlspecialchars($trainee_id) ?>">
          <label for="type">Session Type:</label>
          <select name="type" id="type">
            <option value="all" <?= $typeFilter === 'all' ? 'selected' : '' ?>>All</option>
            <option value="individual" <?= $typeFilter === 'individual' ? 'selected' : '' ?>>Individual</option>
            <option value="group" <?= $typeFilter === 'group' ? 'selected' : '' ?>>Group</option>
          </select>
          <label for="start_date">Start Date:</label>
          <input type="date" name="start_date" value="<?= htmlspecialchars($startDate) ?>">
          <label for="end_date">End Date:</label>
          <input type="date" name="end_date" value="<?= htmlspecialchars($endDate) ?>">
          <button type="submit">Filter</button>
        </form>
      </div>
            <?php if ($sessions): ?>
        <form method="post" class="attendance-form">
          <table id="attendance-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Time</th>
                <th>Type</th>
                <th>Attended</th>
                <th>Notes</th>
                <th>Edit</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($sessions as $s): ?>
                <?php
                  $isLocked = $s['attended'] || !empty($s['notes']);
                  $rowClass = $s['session_type'] === 'individual' ? 'individual-row' : 'group-row';
                ?>
                <tr class="<?= $rowClass ?>">
                  <td><?= date('Y-m-d', strtotime($s['session_date'])) ?></td>
                  <td><?= date('H:i', strtotime($s['session_time'])) ?></td>
                  <td><?= ucfirst($s['session_type']) ?></td>
                  <td>
                    <input type="checkbox" name="attendance[<?= $s['session_id'] ?>]"
                      <?= $s['attended'] ? 'checked' : '' ?>
                      <?= $isLocked ? 'disabled' : '' ?>>
                  </td>
                  <td class="notes-cell">
                    <textarea name="notes[<?= $s['session_id'] ?>]" rows="3"
                      <?= $isLocked ? 'readonly' : '' ?>><?= htmlspecialchars($s['notes'] ?? '') ?></textarea>
                  </td>
                  <td>
                  <?php if ($isLocked): ?>
  <button type="button" class="unlock-btn" onclick="unlockRow(this)">Edit/Unlock</button>
<?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
          <button type="submit">Save Changes</button>
        </form>
      <?php else: ?>
        <p>No supervision sessions recorded for this trainee.</p>
      <?php endif; ?>

      <a href="supervision_attendance_dashboard.php" class="btn-back">← Back to Dashboard</a>
      <a href="#" onclick="exportCSV()" class="btn-export">Export CSV</a>
      <a href="#" onclick="window.print()" class="btn-export">Print View</a>
    </div>
  </div>

  <script>
    function unlockRow(button) {
      const row = button.closest('tr');
      const checkbox = row.querySelector('input[type="checkbox"]');
      const textarea = row.querySelector('textarea');

      if (checkbox) checkbox.disabled = false;
      if (textarea) textarea.readOnly = false;

      button.remove();
    }

    function exportCSV() {
      const rows = [['Date', 'Time', 'Type', 'Attended', 'Notes']];
      document.querySelectorAll('#attendance-table tbody tr').forEach(row => {
        const cells = Array.from(row.querySelectorAll('td')).slice(0, 5).map(td => td.innerText.trim());
        rows.push(cells);
      });
      const csvContent = rows.map(e => e.join(",")).join("\n");
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "attendance_<?= $trainee_id ?>.csv";
      link.click();
    }
  </script>
</body>
</html>