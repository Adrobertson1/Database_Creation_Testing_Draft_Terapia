<?php require 'auth.php'; ?>
<?php
require 'db.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin', 'staff'])) {
    die("Access denied.");
}

$course_id = $_GET['course_id'] ?? null;
$module_id = $_GET['module_id'] ?? null;
$type = $_GET['type'] ?? 'active';

if (!$course_id || !$module_id || !in_array($type, ['active', 'archived'])) {
    die("Invalid parameters.");
}

// Fetch course and module names
$courseStmt = $pdo->prepare("SELECT course_name FROM courses WHERE course_id = ?");
$courseStmt->execute([$course_id]);
$course = $courseStmt->fetch();

$moduleStmt = $pdo->prepare("SELECT module_name FROM modules WHERE module_id = ?");
$moduleStmt->execute([$module_id]);
$module = $moduleStmt->fetch();

if (!$course || !$module) {
    die("Course or module not found.");
}

$is_archived = $type === 'archived' ? 1 : 0;

$traineeStmt = $pdo->prepare("
    SELECT trainee_id, first_name, surname, email, telephone, start_date AS enrolment_date
    FROM trainees
    WHERE course_id = ? AND module_id = ? AND is_archived = ?
    ORDER BY surname
");
$traineeStmt->execute([$course_id, $module_id, $is_archived]);
$trainees = $traineeStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= htmlspecialchars($course['course_name']) ?> — <?= htmlspecialchars($module['module_name']) ?> Trainees</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .dashboard-wrapper { padding: 20px; }
    .main-content h2 { margin-bottom: 10px; }
    .trainee-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    th, td {
      padding: 10px;
      border-bottom: 1px solid #ccc;
      text-align: left;
    }
    th {
      background-color: #6a1b9a;
      color: white;
    }
    .btn-back {
      display: inline-block;
      margin-top: 20px;
      padding: 8px 14px;
      background-color: #6a1b9a;
      color: white;
      border-radius: 4px;
      text-decoration: none;
    }
    .btn-back:hover {
      background-color: #4a148c;
    }
    .trainee-table a {
      color: #6a1b9a;
      font-weight: bold;
      text-decoration: none;
    }
    .trainee-table a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="dashboard-wrapper">
  <?php include 'sidebar.php'; ?>
  <div class="main-content">
    <h2><?= htmlspecialchars($course['course_name']) ?> — <?= htmlspecialchars($module['module_name']) ?> Trainees</h2>
    <h4>Status: <?= ucfirst($type) ?></h4>

    <?php if ($trainees): ?>
      <table class="trainee-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Telephone</th>
            <th>Enrolment Date</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($trainees as $t): ?>
            <tr>
              <td>
                <a href="view_trainee.php?id=<?= urlencode($t['trainee_id']) ?>">
                  <?= htmlspecialchars($t['first_name'] . ' ' . $t['surname']) ?>
                </a>
              </td>
              <td><?= htmlspecialchars($t['email']) ?></td>
              <td><?= htmlspecialchars($t['telephone']) ?></td>
              <td><?= htmlspecialchars($t['enrolment_date']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php else: ?>
      <p>No <?= $type ?> trainees found for this module.</p>
    <?php endif; ?>

    <a href="course_dashboard.php" class="btn-back">← Back to Course Dashboard</a>
  </div>
</div>
</body>
</html>