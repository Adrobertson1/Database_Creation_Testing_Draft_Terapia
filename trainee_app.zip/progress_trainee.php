<?php require 'auth.php'; ?>
<?php
require 'db.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin', 'staff', 'tutor'])) {
  die("Access denied.");
}

$trainee_id = isset($_GET['trainee_id']) ? strtoupper(trim($_GET['trainee_id'])) : '';
$trainee = null;
$nextModule = null;
$progressionHistory = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['trainee_id'], $_POST['next_module_id'], $_POST['confirm_pass']) &&
    in_array($_SESSION['role'], ['superuser', 'admin', 'staff'])) {

  $trainee_id = strtoupper(trim($_POST['trainee_id']));
  $next_module_id = intval($_POST['next_module_id']);
  $performed_by = $_SESSION['username'] ?? 'system';

  $currentModuleStmt = $pdo->prepare("SELECT module_id FROM trainees WHERE trainee_id = ?");
  $currentModuleStmt->execute([$trainee_id]);
  $currentModule = $currentModuleStmt->fetchColumn();

  $pdo->prepare("UPDATE trainees SET module_id = ? WHERE trainee_id = ?")
      ->execute([$next_module_id, $trainee_id]);

  $historyStmt = $pdo->prepare("
    INSERT INTO trainees_history (trainee_id, previous_module_id, new_module_id, changed_by)
    VALUES (?, ?, ?, ?)
  ");
  $historyStmt->execute([$trainee_id, $currentModule, $next_module_id, $performed_by]);

  $pdo->prepare("
    INSERT INTO trainee_logs (trainee_id, action_type, description, performed_by)
    VALUES (?, 'Module Progression', ?, ?)
  ")->execute([
    $trainee_id,
    "Advanced to module ID $next_module_id",
    $performed_by
  ]);

  header("Location: progress_trainee.php?trainee_id=$trainee_id&success=1");
  exit;
}

if ($trainee_id !== '') {
  $stmt = $pdo->prepare("
    SELECT t.trainee_id, t.first_name, t.surname, t.course_id, t.module_id,
           m.module_name, m.year, c.course_name
    FROM trainees t
    JOIN modules m ON t.module_id = m.module_id
    JOIN courses c ON t.course_id = c.course_id
    WHERE t.trainee_id = ?
  ");
  $stmt->execute([$trainee_id]);
  $trainee = $stmt->fetch();

  if ($trainee) {
    $nextStmt = $pdo->prepare("
      SELECT module_id, module_name
      FROM modules
      WHERE course_id = ? AND year > ?
      ORDER BY year ASC
      LIMIT 1
    ");
    $nextStmt->execute([$trainee['course_id'], $trainee['year']]);
    $nextModule = $nextStmt->fetch();

    $percentStmt = $pdo->prepare("
      SELECT s.session_type,
             COUNT(*) AS total,
             SUM(CASE WHEN a.attended = 1 THEN 1 ELSE 0 END) AS attended
      FROM supervision_sessions s
      JOIN supervision_session_trainees st ON s.session_id = st.session_id
      LEFT JOIN supervision_attendance a ON s.session_id = a.session_id AND a.trainee_id = ?
      WHERE st.trainee_id = ? AND s.session_date <= CURDATE()
      GROUP BY s.session_type
    ");
    $percentStmt->execute([$trainee_id, $trainee_id]);
    $percentData = $percentStmt->fetchAll(PDO::FETCH_ASSOC);

    $percentIndividual = 0;
    $percentGroup = 0;
    foreach ($percentData as $row) {
      if ($row['session_type'] === 'individual') {
        $percentIndividual = $row['total'] ? round(($row['attended'] / $row['total']) * 100) : 0;
      }
      if ($row['session_type'] === 'group') {
        $percentGroup = $row['total'] ? round(($row['attended'] / $row['total']) * 100) : 0;
      }
    }

    function getStatusFlag($percent) {
      if ($percent >= 80) return ['flag' => 'green', 'label' => 'Doing Well'];
      if ($percent >= 60) return ['flag' => 'amber', 'label' => 'Needs Monitoring'];
      return ['flag' => 'red', 'label' => 'Failing'];
    }

    $individualStatus = getStatusFlag($percentIndividual);
    $groupStatus = getStatusFlag($percentGroup);

    $assignStmt = $pdo->prepare("
      SELECT score_percent FROM assignment_submissions WHERE trainee_id = ?
    ");
    $assignStmt->execute([$trainee_id]);
    $assignments = $assignStmt->fetchAll(PDO::FETCH_COLUMN);

    $hasFailed = false;
    foreach ($assignments as $score) {
      if ($score !== null && $score < 50) {
        $hasFailed = true;
        break;
      }
    }
    $assignmentFlag = $hasFailed ? 'red' : 'green';
    $assignmentLabel = $hasFailed ? 'Failed Assignment(s)' : 'All Passed';

    $progressionStmt = $pdo->prepare("
      SELECT h.changed_at, c.course_name,
             m_from.module_name AS module_from,
             m_to.module_name AS module_to,
             h.changed_by
      FROM trainees_history h
      JOIN trainees t ON h.trainee_id = t.trainee_id
      JOIN courses c ON t.course_id = c.course_id
      LEFT JOIN modules m_from ON h.previous_module_id = m_from.module_id
      LEFT JOIN modules m_to ON h.new_module_id = m_to.module_id
      WHERE h.trainee_id = ?
      ORDER BY h.changed_at DESC
    ");
    $progressionStmt->execute([$trainee_id]);
    $progressionHistory = $progressionStmt->fetchAll();
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Progress Trainee</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f8;
      margin: 0;
      padding: 0;
    }
    .dashboard-wrapper {
      display: flex;
    }
    .main-content {
      flex: 1;
      padding: 40px;
      background: #fff;
    }
    details {
      margin-bottom: 40px;
      border: 1px solid #ccc;
      border-radius: 6px;
      padding: 20px;
      background: #fafafa;
    }
    summary {
      font-size: 18px;
      font-weight: bold;
      cursor: pointer;
      margin-bottom: 10px;
    }
    label {
      display: block;
      margin-top: 15px;
      font-weight: bold;
    }
    input[type="text"], select {
      width: 100%;
      padding: 8px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
    .btn {
      margin-top: 20px;
      padding: 12px 24px;
      background-color: #6a1b9a;
      color: white;
      border: none;
      border-radius: 4px;
      font-weight: bold;
      cursor: pointer;
    }
    .btn:hover {
      background-color: #4a148c;
    }
    .status-indicator {
      display: inline-block;
      width: 12px;
      height: 12px;
      border-radius: 50%;
      margin-right: 6px;
    }
    .status-block {
      margin-top: 30px;
      padding: 20px;
      background: #f0f0f0;
      border-radius: 6px;
    }
    .success-banner {
      background-color: #e0f7fa;
      padding: 10px;
      border-left: 4px solid #00796b;
      margin-top: 20px;
    }
    .confirm-box {
      margin-top: 20px;
      padding: 15px;
      background-color: #f9f9f9;
      border: 1px solid #ccc;
      border-radius: 6px;
    }
    .confirm-box label {
      font-weight: bold;
      font-size: 16px;
    }
    .confirm-box input[type="checkbox"] {
      transform: scale(1.5);
      margin-right: 10px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    th, td {
      padding: 12px;
      border: 1px solid #999;
      text-align: left;
      vertical-align: top;
    }
    th {
      background-color: #6a1b9a;
      color: white;
    }
    tbody tr:hover {
      background-color: #f5f5f5;
    }
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="dashboard-wrapper">
<?php include 'sidebar.php'; ?>
<div class="main-content">

<details open>
  <summary>Progress Trainee</summary>
  <form method="get" action="progress_trainee.php">
    <label for="trainee_id">Enter Trainee ID:</label>
    <input type="text" name="trainee_id" id="trainee_id" required>
    <button type="submit" class="btn">Lookup</button>
  </form>

  <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
    <div class="success-banner">✅ Trainee successfully advanced to the next module.</div>
  <?php endif; ?>

  <?php if ($trainee): ?>
    <hr>
    <p><strong>Name:</strong> <?= htmlspecialchars($trainee['first_name'] . ' ' . $trainee['surname']) ?></p>
    <p><strong>Course:</strong> <?= htmlspecialchars($trainee['course_name']) ?></p>
    <p><strong>Current Module:</strong> <?= htmlspecialchars($trainee['module_name']) ?> (Year <?= $trainee['year'] ?>)</p>

    <?php if ($nextModule): ?>
      <p><strong>Next Module:</strong> <?= htmlspecialchars($nextModule['module_name']) ?></p>
      <?php if (in_array($_SESSION['role'], ['superuser', 'admin', 'staff'])): ?>
        <form method="post" action="progress_trainee.php">
          <input type="hidden" name="trainee_id" value="<?= $trainee['trainee_id'] ?>">
          <input type="hidden" name="next_module_id" value="<?= $nextModule['module_id'] ?>">
          <div class="confirm-box">
            <label><input type="checkbox" name="confirm_pass" required> Confirm trainee has passed</label>
          </div>
          <button type="submit" class="btn">Advance Trainee to Next Module</button>
        </form>
      <?php else: ?>
        <p><em>You do not have permission to progress trainees.</em></p>
      <?php endif; ?>
    <?php else: ?>
      <p><em>This trainee is already on the final module.</em></p>
    <?php endif; ?>

    <div class="status-block">
      <h3>Status Overview</h3>
      <p><strong>Individual Supervision:</strong>
        <span class="status-indicator" style="background-color:<?= $individualStatus['flag'] === 'green' ? '#4CAF50' : ($individualStatus['flag'] === 'amber' ? '#FFC107' : '#F44336') ?>"></span>
        <?= $individualStatus['label'] ?> (<?= $percentIndividual ?>%)
      </p>
      <p><strong>Group Supervision:</strong>
        <span class="status-indicator" style="background-color:<?= $groupStatus['flag'] === 'green' ? '#4CAF50' : ($groupStatus['flag'] === 'amber' ? '#FFC107' : '#F44336') ?>"></span>
        <?= $groupStatus['label'] ?> (<?= $percentGroup ?>%)
      </p>
      <p><strong>Assignment Status:</strong>
        <span class="status-indicator" style="background-color:<?= $assignmentFlag === 'green' ? '#4CAF50' : '#F44336' ?>"></span>
        <?= $assignmentLabel ?>
      </p>
    </div>

    <?php if ($progressionHistory && count($progressionHistory) > 0): ?>
      <div class="status-block">
        <h3>Progression History</h3>
        <table>
          <thead>
            <tr>
              <th>Date Enacted</th>
              <th>Course Name</th>
              <th>Module From</th>
              <th>Module To</th>
              <th>Enacted By</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($progressionHistory as $row): ?>
              <tr>
                <td><?= date('d M Y', strtotime($row['changed_at'])) ?></td>
                <td><?= htmlspecialchars($row['course_name']) ?></td>
                <td><?= htmlspecialchars($row['module_from'] ?? '—') ?></td>
                <td><?= htmlspecialchars($row['module_to'] ?? '—') ?></td>
                <td><?= htmlspecialchars($row['changed_by']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  <?php endif; ?>
</details>
<details open>
  <summary>Browse Trainees</summary>
  <form method="get" action="progress_trainee.php">
    <label for="filter_course">Course:</label>
    <select name="filter_course" id="filter_course" required>
      <option value="">Select Course</option>
      <?php
      $courseList = $pdo->query("SELECT course_id, course_name FROM courses ORDER BY course_name ASC")->fetchAll();
      foreach ($courseList as $course) {
        $selected = isset($_GET['filter_course']) && $_GET['filter_course'] == $course['course_id'] ? 'selected' : '';
        echo "<option value=\"{$course['course_id']}\" $selected>" . htmlspecialchars($course['course_name']) . "</option>";
      }
      ?>
    </select>

    <label for="filter_module">Module:</label>
    <select name="filter_module" id="filter_module" required>
      <option value="">Select Module</option>
    </select>

    <button type="submit" class="btn">Search</button>
  </form>

  <?php
  if (isset($_GET['filter_course'], $_GET['filter_module']) &&
      $_GET['filter_course'] !== '' && $_GET['filter_module'] !== '') {

    $courseId = $_GET['filter_course'];
    $moduleId = $_GET['filter_module'];

    $browseStmt = $pdo->prepare("
      SELECT t.trainee_id, t.first_name, t.surname, tc.enrolment_date
      FROM trainees t
      JOIN trainee_courses tc ON t.trainee_id = tc.trainee_id
      WHERE t.course_id = ? AND t.module_id = ?
      ORDER BY t.surname ASC, t.first_name ASC
    ");
    $browseStmt->execute([$courseId, $moduleId]);
    $results = $browseStmt->fetchAll();

    if ($results):
  ?>
    <p style="margin-top: 20px; font-style: italic; color: #555;">
      Once identified, copy/paste the desired ID into the box above to review progression options.
    </p>
    <button onclick="exportTableToCSV()" class="btn">Export CSV</button>
    <div style="overflow-x:auto; margin-top:20px;">
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Trainee ID</th>
            <th>Enrolment Year</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($results as $row): ?>
            <tr>
              <td>
                <a href="view_trainee.php?id=<?= urlencode($row['trainee_id']) ?>">
                  <?= htmlspecialchars($row['first_name'] . ' ' . $row['surname']) ?>
                </a>
              </td>
              <td><?= htmlspecialchars($row['trainee_id']) ?></td>
              <td><?= date('Y', strtotime($row['enrolment_date'])) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <p><em>No trainees found for selected course and module.</em></p>
  <?php endif; } ?>
</details>
</div>
</div>

<script>
document.getElementById('filter_course').addEventListener('change', function () {
  const courseId = this.value;
  const moduleSelect = document.getElementById('filter_module');

  while (moduleSelect.firstChild) {
    moduleSelect.removeChild(moduleSelect.firstChild);
  }

  const loadingOption = document.createElement('option');
  loadingOption.textContent = 'Loading...';
  loadingOption.disabled = true;
  loadingOption.selected = true;
  moduleSelect.appendChild(loadingOption);

  fetch('get_modules_by_course.php?course_id=' + encodeURIComponent(courseId))
    .then(response => response.json())
    .then(data => {
      moduleSelect.innerHTML = '';
      if (data.length === 0) {
        const noOption = document.createElement('option');
        noOption.textContent = 'No modules found';
        noOption.disabled = true;
        moduleSelect.appendChild(noOption);
        return;
      }

      const defaultOption = document.createElement('option');
      defaultOption.textContent = 'Select Module';
      defaultOption.value = '';
      moduleSelect.appendChild(defaultOption);

      data.forEach(module => {
        const option = document.createElement('option');
        option.value = module.module_id;
        option.textContent = module.module_name;
        moduleSelect.appendChild(option);
      });
    })
    .catch(error => {
      moduleSelect.innerHTML = '';
      const errorOption = document.createElement('option');
      errorOption.textContent = 'Error loading modules';
      errorOption.disabled = true;
      moduleSelect.appendChild(errorOption);
      console.error('Module fetch error:', error);
    });
});

function exportTableToCSV() {
  const rows = document.querySelectorAll("table tr");
  let csv = [];
  rows.forEach(row => {
    const cols = Array.from(row.querySelectorAll("td, th")).map(col => `"${col.innerText}"`);
    csv.push(cols.join(","));
  });
  const blob = new Blob([csv.join("\n")], { type: "text/csv" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "trainees.csv";
  link.click();
}
</script>
</body>
</html>