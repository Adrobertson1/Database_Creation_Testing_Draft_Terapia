<?php
session_start();
require 'db.php';

$error = '';

function logAudit($pdo, $user_id, $role, $type, $detail) {
    $stmt = $pdo->prepare("
        INSERT INTO audit_log (user_id, role, action_type, action_detail, ip_address, timestamp)
        VALUES (?, ?, ?, ?, ?, NOW())
    ");
    $stmt->execute([
        $user_id,
        $role,
        $type,
        $detail,
        $_SERVER['REMOTE_ADDR']
    ]);
}

function logLoginActivity($pdo, $user_id, $role, $email) {
    $stmt = $pdo->prepare("
        INSERT INTO login_activity (user_id, role, email, ip_address, user_agent, login_time)
        VALUES (?, ?, ?, ?, ?, NOW())
    ");
    $stmt->execute([
        $user_id,
        $role,
        $email,
        $_SERVER['REMOTE_ADDR'],
        $_SERVER['HTTP_USER_AGENT']
    ]);
}

function logFailedLogin($pdo, $username, $reason) {
    $stmt = $pdo->prepare("
        INSERT INTO login_attempts (username, ip_address, user_agent, success, reason, attempt_time)
        VALUES (?, ?, ?, 0, ?, NOW())
    ");
    $stmt->execute([
        $username,
        $_SERVER['REMOTE_ADDR'],
        $_SERVER['HTTP_USER_AGENT'],
        $reason
    ]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        $error = "Please enter both email and password.";
    } else {
        $sources = [
            ['table' => 'users',       'id' => 'user_id',       'condition' => 'is_active = 1'],
            ['table' => 'staff',       'id' => 'staff_id',      'condition' => 'is_archived = 0'],
            ['table' => 'trainees',    'id' => 'trainee_id',    'condition' => 'is_archived = 0'],
            ['table' => 'tutors',      'id' => 'tutor_id',      'condition' => 'is_archived = 0'],
            ['table' => 'supervisors', 'id' => 'supervisor_id', 'condition' => 'is_archived = 0']
        ];

        $user = null;
        $source = null;

        foreach ($sources as $src) {
            $selectRole = in_array($src['table'], ['users', 'staff'])
                ? 'role'
                : "'" . rtrim($src['table'], 's') . "' AS role";

            $hasNameFields = in_array($src['table'], ['staff', 'trainees', 'tutors', 'supervisors']);
            $nameFields = $hasNameFields
                ? 'first_name, surname,'
                : "'System' AS first_name, 'User' AS surname,";

            $stmt = $pdo->prepare("
                SELECT {$src['id']} AS user_id, email, password, failed_attempts, is_archived, account_locked,
                       $nameFields $selectRole
                FROM {$src['table']}
                WHERE email = ? AND {$src['condition']}
                LIMIT 1
            ");
            $stmt->execute([$email]);
            $row = $stmt->fetch();
            if ($row) {
                $user = $row;
                $source = $src['table'];
                break;
            }
        }

        if ($user) {
            if ($user['is_archived'] || ($user['account_locked'] ?? 0)) {
                logFailedLogin($pdo, $email, 'Account locked');
                $error = "Your account has been locked due to multiple failed login attempts. Please contact the administrator.";
            } elseif (!password_verify($password, $user['password'])) {
                $attempts = ($user['failed_attempts'] ?? 0) + 1;

                if ($attempts >= 5) {
                    $pdo->prepare("UPDATE {$source} SET account_locked = 1 WHERE email = ?")->execute([$email]);
                    logFailedLogin($pdo, $email, 'Account locked after 5 failed attempts');
                    $error = "Your account has been locked due to multiple failed login attempts. Please contact the administrator.";
                } else {
                    $pdo->prepare("UPDATE {$source} SET failed_attempts = ? WHERE email = ?")->execute([$attempts, $email]);
                    logFailedLogin($pdo, $email, 'Incorrect password');
                    $remaining = 5 - $attempts;
                    $error = "Login failed. You have {$remaining} attempt" . ($remaining === 1 ? '' : 's') . " remaining before the account is locked.";
                }
            } else {
                $pdo->prepare("UPDATE {$source} SET failed_attempts = 0 WHERE email = ?")->execute([$email]);
                $role = strtolower(trim($user['role']));
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['role'] = $role;
                $_SESSION['name'] = $user['first_name'] . ' ' . $user['surname'];
                $_SESSION['email'] = $email;
                $_SESSION['initiated'] = 1;
                $_SESSION['last_activity'] = time();
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

                logAudit($pdo, $user['user_id'], $role, 'login', 'Successful login');
                logLoginActivity($pdo, $user['user_id'], $role, $email);
                header("Location: dashboard.php");
                exit;
            }
        } else {
            logFailedLogin($pdo, $email, 'Email not found');
            $error = "Login failed.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>System Login</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background: #E6D6EC;
      color: #000;
    }
    .login-container {
      max-width: 400px;
      margin: 80px auto;
      background: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      text-align: center;
    }
    .login-container img.logo {
      display: block;
      margin: 0 auto 20px auto;
      max-width: 160px;
      height: auto;
    }
    .login-container h2 {
      margin-bottom: 20px;
      color: #850069;
      font-family: 'Josefin Sans', sans-serif;
    }
    .login-container label {
      display: block;
      margin-top: 15px;
      font-weight: bold;
      text-align: left;
    }
    .login-container input {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 16px;
    }
    .login-container input[disabled] {
      background-color: #f0f0f0;
      color: #999;
      cursor: not-allowed;
    }
    .login-container button {
      margin-top: 20px;
      padding: 12px;
      background-color: #850069;
      color: white;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      width: 100%;
      font-family: 'Josefin Sans', serif;
      font-size: 18px;
    }
    .login-container button:hover {
      background-color: #BB9DC6;
    }
    .message.error {
      margin-top: 15px;
      color: #d32f2f;
      font-weight: bold;
    }
    .oauth-login {
      margin-top: 30px;
    }
    .microsoft-login {
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: #f3f3f3;
      color: #666;
      border: 1px solid #ccc;
      border-radius: 6px;
      padding: 10px;
      width: 100%;
      font-size: 16px;
      font-weight: bold;
      cursor: not-allowed;
      opacity: 0.6;
      position: relative;
    }
    .microsoft-login:hover::after {
      content: attr(title);
      position: absolute;
      top: -30px;
      left: 50%;
      transform: translateX(-50%);
      background: #333;
      color: #fff;
      padding: 6px 10px;
      border-radius: 4px;
      font-size: 13px;
      white-space: nowrap;
      z-index: 10;
    }
    .microsoft-icon {
      width: 20px;
      height: 20px;
          }
    .microsoft-icon {
      width: 20px;
      height: 20px;
      margin-right: 10px;
    }
    .forgot-password {
      margin-top: 12px;
      text-align: center;
    }
    .forgot-password a {
      color: #6a1b9a;
      text-decoration: none;
      font-size: 14px;
    }
    .forgot-password a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
<div class="login-container">
  <img src="Assets/logo.png" alt="Terapia Logo" class="logo">
  <h2>Login</h2>

  <?php if ($error): ?>
    <div class="message error"><?= $error ?></div>
  <?php endif; ?>

  <form method="post">
    <label>Email Address:</label>
    <input type="email" name="email" required>

    <label>Password:</label>
    <input type="password" name="password" required>

    <label>MFA CODE:</label>
    <input type="text" placeholder="Disabled in Sandbox" disabled>

    <button type="submit">Login</button>

    <p class="forgot-password">
      <a href="forgot_password.php">Forgot your password?</a>
    </p>
  </form>

  <div class="oauth-login">
    <button class="microsoft-login" disabled title="Not available in sandbox">
      <img src="Assets/microsoft-logo.png" alt="Microsoft Logo" class="microsoft-icon">
      Sign in with Microsoft
    </button>
  </div>
</div>
</body>
</html>