<?php require 'auth.php'; ?>
<?php
require 'db.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin', 'staff'])) {
  die("Access denied.");
}

// Fetch all staff with account status
$stmt = $pdo->prepare("
  SELECT st.*, 
         u.account_locked, u.failed_attempts
  FROM staff st
  LEFT JOIN users u ON st.staff_id = u.user_id
  ORDER BY st.surname
");
$stmt->execute();
$staff = $stmt->fetchAll(PDO::FETCH_ASSOC);

// CSV export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename=\"staff_records.csv\"');
  $out = fopen('php://output', 'w');
  fputcsv($out, [
    'ID', 'Name', 'Email', 'Telephone', 'Start Date', 'Archived',
    'Job Title', 'Role', 'DBS Status', 'DBS Date', 'DBS Reference',
    'DBS Update Service', 'Disability Status', 'Disability Type',
    'Town/City', 'Postcode', 'Address Line 1', 'Account Locked', 'Failed Attempts'
  ]);
  foreach ($staff as $s) {
    fputcsv($out, [
      $s['staff_id'],
      $s['first_name'] . ' ' . $s['surname'],
      $s['email'],
      $s['telephone'],
      $s['start_date'],
      $s['is_archived'] ? 'Yes' : 'No',
      $s['job_title'],
      $s['role'],
      $s['dbs_status'] ?? '—',
      $s['dbs_date'] ?? '—',
      $s['dbs_reference'] ?? '—',
      !empty($s['dbs_update_service']) ? 'Yes' : 'No',
      $s['disability_status'] ?? '—',
      $s['disability_type'] ?? '—',
      $s['town_city'] ?? '—',
      $s['postcode'] ?? '—',
      $s['address_line1'] ?? '—',
      !empty($s['account_locked']) ? 'Yes' : 'No',
      $s['failed_attempts'] ?? '0'
    ]);
  }
  fclose($out);
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>All Staff Records</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .main-content { padding: 40px; max-width: 1600px; margin: auto; }
    .staff-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    .staff-table th, .staff-table td {
      padding: 10px;
      border-bottom: 1px solid #ccc;
      vertical-align: top;
    }
    .staff-table th {
      background-color: #6a1b9a;
      color: white;
    }
    .btn {
      display: inline-block;
      padding: 8px 16px;
      background-color: #6a1b9a;
      color: white;
      text-decoration: none;
      border-radius: 4px;
      font-weight: bold;
      margin-bottom: 20px;
    }
    .btn:hover {
      background-color: #4a148c;
    }
    .profile-img {
      max-width: 80px;
      max-height: 80px;
      border-radius: 4px;
    }
    .no-results {
      font-style: italic;
      color: #777;
    }
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="dashboard-wrapper">
  <?php include 'sidebar.php'; ?>
  <div class="main-content">
    <h2>All Staff Records</h2>

    <a href="?export=csv" class="btn">Export CSV</a>

    <?php if (count($staff) === 0): ?>
      <p class="no-results">No staff found.</p>
    <?php else: ?>
      <table class="staff-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Telephone</th>
            <th>Start Date</th>
            <th>Archived</th>
            <th>Job Title</th>
            <th>Role</th>
            <th>DBS Status</th>
            <th>DBS Date</th>
            <th>DBS Reference</th>
            <th>DBS Update</th>
            <th>Disability</th>
            <th>Location</th>
            <th>Address</th>
            <th>Profile</th>
            <th>Account Locked</th>
            <th>Failed Attempts</th>
            <th>View</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($staff as $s): ?>
            <tr>
              <td><?= htmlspecialchars($s['staff_id']) ?></td>
              <td><?= htmlspecialchars($s['first_name'] . ' ' . $s['surname']) ?></td>
              <td><?= htmlspecialchars($s['email']) ?></td>
              <td><?= htmlspecialchars($s['telephone']) ?></td>
              <td><?= htmlspecialchars($s['start_date']) ?></td>
              <td><?= !empty($s['is_archived']) ? 'Yes' : 'No' ?></td>
              <td><?= htmlspecialchars($s['job_title'] ?? '—') ?></td>
              <td><?= htmlspecialchars($s['role'] ?? '—') ?></td>
              <td><?= htmlspecialchars($s['dbs_status'] ?? '—') ?></td>
              <td><?= htmlspecialchars($s['dbs_date'] ?? '—') ?></td>
              <td><?= htmlspecialchars($s['dbs_reference'] ?? '—') ?></td>
              <td><?= !empty($s['dbs_update_service']) ? 'Yes' : 'No' ?></td>
              <td>
                <?= htmlspecialchars($s['disability_status'] ?? '—') ?><br>
                <?= htmlspecialchars($s['disability_type'] ?? '—') ?>
              </td>
              <td>
                <?= htmlspecialchars($s['town_city'] ?? '—') ?><br>
                <?= htmlspecialchars($s['postcode'] ?? '—') ?>
              </td>
              <td><?= htmlspecialchars($s['address_line1'] ?? '—') ?></td>
              <td>
                <?php if (!empty($s['profile_image']) && file_exists('uploads/' . basename($s['profile_image']))): ?>
                  <img src="<?= 'uploads/' . htmlspecialchars(basename($s['profile_image'])) ?>" class="profile-img" alt="Profile">
                <?php else: ?>
                  —
                <?php endif; ?>
              </td>
              <td><?= !empty($s['account_locked']) ? 'Yes' : 'No' ?></td>
              <td><?= htmlspecialchars($s['failed_attempts'] ?? '0') ?></td>
              <td>
                <a href="view_staff.php?id=<?= $s['staff_id'] ?>" class="btn" target="_blank">View</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
</body>
</html>