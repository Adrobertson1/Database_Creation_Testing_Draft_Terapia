<?php require 'auth.php'; ?>
<?php
require 'db.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin', 'staff'])) {
  die("Access denied.");
}

// Fetch locked accounts from users table
$stmt = $pdo->prepare("
  SELECT user_id, username, email, role, account_locked
  FROM users
  WHERE account_locked = 1 AND is_archived = 0
");
$stmt->execute();
$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

// CSV export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename=locked_accounts.csv');
  header('Pragma: no-cache');
  header('Expires: 0');

  $output = fopen('php://output', 'w');
  fputcsv($output, ['User ID', 'Username', 'Email', 'Role', 'Profile Link']);
  foreach ($records as $r) {
    $link = match($r['role']) {
      'tutor' => "view_tutor.php?id={$r['user_id']}",
      'staff' => "view_staff.php?id={$r['user_id']}",
      'supervisor' => "view_supervisor.php?id={$r['user_id']}",
      'admin' => "view_admin.php?id={$r['user_id']}",
      'trainee' => "view_trainee.php?id={$r['user_id']}",
      default => "#"
    };
    fputcsv($output, [
      $r['user_id'],
      $r['username'],
      $r['email'] ?? '—',
      $r['role'],
      $link
    ]);
  }
  fclose($output);
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Locked Accounts</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .main-content { padding: 40px; max-width: 1200px; margin: auto; }
    .record-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    .record-table th, .record-table td {
      padding: 10px;
      border-bottom: 1px solid #ccc;
    }
    .record-table th {
      background-color: #6a1b9a;
      color: white;
    }
    .btn {
      display: inline-block;
      padding: 8px 16px;
      background-color: #6a1b9a;
      color: white;
      text-decoration: none;
      border-radius: 4px;
      font-weight: bold;
      margin-bottom: 20px;
    }
    .btn:hover {
      background-color: #4a148c;
    }
    .name-link {
      color: #6a1b9a;
      font-weight: bold;
      text-decoration: none;
    }
    .name-link:hover {
      text-decoration: underline;
    }
    .no-results {
      font-style: italic;
      color: #777;
    }
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="dashboard-wrapper">
  <?php include 'sidebar.php'; ?>
  <div class="main-content">
    <h2>Locked Accounts</h2>

    <a href="view_locked_accounts.php?export=csv" class="btn">Export CSV</a>

    <?php if (count($records) === 0): ?>
      <p class="no-results">No locked accounts found.</p>
    <?php else: ?>
      <table class="record-table">
        <thead>
          <tr>
            <th>User ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Role</th>
            <th>View</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($records as $r): ?>
            <?php
              $link = match($r['role']) {
                'tutor' => "view_tutor.php?id={$r['user_id']}",
                'staff' => "view_staff.php?id={$r['user_id']}",
                'supervisor' => "view_supervisor.php?id={$r['user_id']}",
                'admin' => "view_admin.php?id={$r['user_id']}",
                'trainee' => "view_trainee.php?id={$r['user_id']}",
                default => "#"
              };
            ?>
            <tr>
              <td><?= htmlspecialchars($r['user_id']) ?></td>
              <td><?= htmlspecialchars($r['username']) ?></td>
              <td><?= htmlspecialchars($r['email'] ?? '—') ?></td>
              <td><?= htmlspecialchars($r['role']) ?></td>
              <td><a href="<?= $link ?>" class="btn" target="_blank">View</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
</body>
</html>