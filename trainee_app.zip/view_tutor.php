<?php require 'auth.php'; ?>
<?php
require 'db.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin', 'staff'])) {
  die("Access denied.");
}

$tutor_id = $_GET['id'] ?? null;

if (!$tutor_id || !is_numeric($tutor_id)) {
  die("Invalid tutor ID.");
}

$stmt = $pdo->prepare("SELECT * FROM tutors WHERE tutor_id = ?");
$stmt->execute([$tutor_id]);
$tutor = $stmt->fetch();

if (!$tutor) {
  die("Tutor not found.");
}

$photoPath = '';
if (!empty($tutor['profile_image'])) {
  $photoPath = 'uploads/' . basename($tutor['profile_image']);
  if (!file_exists($photoPath)) {
    $photoPath = '';
  }
}

$courseStmt = $pdo->prepare("
  SELECT c.course_name
  FROM tutor_courses tc
  JOIN courses c ON tc.course_id = c.course_id
  WHERE tc.tutor_id = ?
");
$courseStmt->execute([$tutor_id]);
$courses = $courseStmt->fetchAll(PDO::FETCH_COLUMN);

$moduleStmt = $pdo->prepare("
  SELECT m.module_name
  FROM tutor_modules tm
  JOIN modules m ON tm.module_id = m.module_id
  WHERE tm.tutor_id = ?
");
$moduleStmt->execute([$tutor_id]);
$modules = $moduleStmt->fetchAll(PDO::FETCH_COLUMN);

// Check account lock status
$userStatusStmt = $pdo->prepare("SELECT account_locked, failed_attempts FROM users WHERE user_id = ?");
$userStatusStmt->execute([$tutor['tutor_id']]);
$userStatus = $userStatusStmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Tutor</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .profile-box {
      background: #f9f9f9;
      padding: 20px;
      border-radius: 8px;
      max-width: 700px;
      margin-bottom: 30px;
      border: 1px solid #ccc;
    }
    .profile-label {
      font-weight: bold;
      display: inline-block;
      width: 180px;
    }
    .profile-field {
      margin-bottom: 10px;
    }
    .profile-photo img {
      max-width: 120px;
      border-radius: 8px;
      border: 1px solid #ccc;
    }
    .btn-back {
      margin-top: 20px;
      display: inline-block;
      padding: 8px 16px;
      background-color: #850069;
      color: #fff;
      text-decoration: none;
      border-radius: 4px;
    }
    .btn-back:hover {
      background-color: #BB9DC6;
    }
    .message.success {
      margin-top: 15px;
      color: #2e7d32;
      font-weight: bold;
    }
    .message.error {
      margin-top: 15px;
      color: #d32f2f;
      font-weight: bold;
    }
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="dashboard-wrapper">
  <?php include 'sidebar.php'; ?>
  <div class="main-content">
    <h2>View Tutor</h2>

    <div class="profile-box">
      <h3><?= htmlspecialchars($tutor['first_name'] . ' ' . $tutor['surname']) ?></h3>

      <div class="profile-photo">
        <?php if ($photoPath): ?>
          <img src="<?= $photoPath ?>" alt="Tutor Photo">
        <?php else: ?>
          <em>No photo available.</em>
        <?php endif; ?>
      </div>

      <div class="profile-field"><span class="profile-label">Email:</span> <?= htmlspecialchars($tutor['email'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Telephone:</span> <?= htmlspecialchars($tutor['telephone'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Date of Birth:</span> <?= htmlspecialchars($tutor['date_of_birth'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Town/City:</span> <?= htmlspecialchars($tutor['town_city'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Postcode:</span> <?= htmlspecialchars($tutor['postcode'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Address Line 1:</span> <?= htmlspecialchars($tutor['address_line1'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Disability Status:</span> <?= htmlspecialchars($tutor['disability_status'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Disability Type:</span> <?= htmlspecialchars($tutor['disability_type'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Start Date:</span> <?= htmlspecialchars($tutor['start_date'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Job Title:</span> <?= htmlspecialchars($tutor['job_title'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Role:</span> <?= htmlspecialchars($tutor['role'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">DBS Status:</span> <?= htmlspecialchars($tutor['dbs_status'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">DBS Issue Date:</span> <?= htmlspecialchars($tutor['dbs_date'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">DBS Reference:</span> <?= htmlspecialchars($tutor['dbs_reference'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">DBS Update Service:</span> <?= $tutor['dbs_update_service'] ? 'Yes' : 'No' ?></div>

      <div class="profile-field">
        <span class="profile-label">Assigned Courses:</span>
        <?= $courses ? implode(', ', array_map('htmlspecialchars', $courses)) : '-' ?>
      </div>

      <div class="profile-field">
        <span class="profile-label">Assigned Modules:</span>
        <?= $modules ? implode(', ', array_map('htmlspecialchars', $modules)) : '-' ?>
      </div>

<?php if (in_array($_SESSION['role'], ['superuser', 'admin']) && $userStatus && $userStatus['account_locked']): ?>
  <form method="post" action="unlock_user.php" style="margin-top: 20px;">
    <input type="hidden" name="user_id" value="<?= $tutor['tutor_id'] ?>">
    <input type="hidden" name="tutor_id" value="<?= $tutor['tutor_id'] ?>">
    <button type="submit" class="btn">Unlock Account</button>
    <p style="margin-top: 8px; color: #d32f2f;">Account is currently locked after <?= $userStatus['failed_attempts'] ?> failed attempts.</p>
  </form>
<?php endif; ?>

<?php if (in_array($_SESSION['role'], ['superuser', 'admin'])): ?>
  <form method="post" action="reset_password_admin.php" style="margin-top: 30px;">
    <input type="hidden" name="user_id" value="<?= $tutor['tutor_id'] ?>">
    <input type="hidden" name="role" value="tutor">
    <label for="new_password"><strong>Set New Password:</strong></label>
    <input
      type="password"
      name="new_password"
      id="new_password"
      required
      pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$"
      title="Password must be at least 8 characters long and include uppercase, lowercase, number, and special character."
      style="width: 100%; padding: 8px; margin-top: 8px;"
    >
    <button type="submit" class="btn" style="margin-top: 10px;">Update Password</button>
  </form>
<?php endif; ?>

<?php if (isset($_GET['reset']) && $_GET['reset'] === '1'): ?>
  <div class="message success">Password successfully updated.</div>
<?php elseif (isset($_GET['reset']) && $_GET['reset'] === 'weak'): ?>
  <div class="message error">Password does not meet strength requirements.</div>
<?php endif; ?>
      <a href="tutors.php?view=<?= $tutor['is_archived'] ? 'archived' : 'active' ?>" class="btn-back">← Back to List</a>
      <a href="edit_tutor.php?tutor_id=<?= $tutor['tutor_id'] ?>" class="btn-back" style="margin-left: 10px;">✎ Edit Tutor</a>
    </div>
  </div>
</div>
</body>
</html>