<?php require 'auth.php'; ?>
<?php
require 'db.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin', 'staff'])) {
  die("Access denied.");
}

$supervisor_id = $_GET['id'] ?? null;
if (!$supervisor_id || !is_numeric($supervisor_id)) {
  die("Invalid access.");
}

$stmt = $pdo->prepare("SELECT * FROM supervisors WHERE supervisor_id = ?");
$stmt->execute([$supervisor_id]);
$supervisor = $stmt->fetch();

if (!$supervisor) {
  die("Supervisor not found.");
}

$tStmt = $pdo->prepare("
  SELECT trainee_id, first_name, surname
  FROM trainees
  WHERE supervisor_id = ?
  ORDER BY surname
");
$tStmt->execute([$supervisor_id]);
$trainees = $tStmt->fetchAll();

$cStmt = $pdo->prepare("
  SELECT c.course_name
  FROM supervisor_courses sc
  JOIN courses c ON sc.course_id = c.course_id
  WHERE sc.supervisor_id = ?
");
$cStmt->execute([$supervisor_id]);
$courses = $cStmt->fetchAll(PDO::FETCH_COLUMN);

$mStmt = $pdo->prepare("
  SELECT m.module_name
  FROM supervisor_modules sm
  JOIN modules m ON sm.module_id = m.module_id
  WHERE sm.supervisor_id = ?
");
$mStmt->execute([$supervisor_id]);
$modules = $mStmt->fetchAll(PDO::FETCH_COLUMN);

// Check account lock status
$userStatusStmt = $pdo->prepare("SELECT account_locked, failed_attempts FROM users WHERE user_id = ?");
$userStatusStmt->execute([$supervisor['supervisor_id']]);
$userStatus = $userStatusStmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Supervisor Profile</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .main-content { padding: 40px; }
    .profile-card {
      background-color: #f9f9f9;
      padding: 20px;
      border-radius: 8px;
      border: 1px solid #ddd;
      max-width: 700px;
    }
    .profile-card img {
      width: 80px;
      height: 80px;
      object-fit: cover;
      border-radius: 6px;
      border: 1px solid #ccc;
      margin-bottom: 10px;
    }
    .profile-card p {
      margin: 8px 0;
      font-size: 16px;
    }
    .profile-card strong {
      color: #6a1b9a;
    }
    .trainee-list, .curriculum-list {
      margin-top: 20px;
    }
    .trainee-list ul, .curriculum-list ul {
      padding-left: 20px;
    }
    .btn-edit {
      display: inline-block;
      margin-top: 20px;
      padding: 8px 16px;
      background-color: #850069;
      color: white;
      text-decoration: none;
      border-radius: 4px;
      font-weight: bold;
    }
    .btn-edit:hover {
      background-color: #BB9DC6;
    }
    .message.success {
      margin-top: 15px;
      color: #2e7d32;
      font-weight: bold;
    }
    .message.error {
      margin-top: 15px;
      color: #d32f2f;
      font-weight: bold;
    }
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="dashboard-wrapper">
  <?php include 'sidebar.php'; ?>
  <div class="main-content">
    <h2>Supervisor Profile</h2>

    <div class="profile-card">
      <?php
      $imagePath = $supervisor['profile_image'] ?? '';
      $fullPath = 'uploads/' . basename($imagePath);
      if (!empty($imagePath) && file_exists($fullPath)) {
        echo '<img src="' . htmlspecialchars($fullPath) . '" alt="Supervisor Photo">';
      } else {
        echo '<span style="color:#999;">No photo available</span>';
      }
      ?>
      <p><strong>Name:</strong> <?= htmlspecialchars($supervisor['first_name'] . ' ' . $supervisor['surname']) ?></p>
      <p><strong>Email:</strong> <?= htmlspecialchars($supervisor['email'] ?? '—') ?></p>
      <p><strong>Telephone:</strong> <?= htmlspecialchars($supervisor['telephone'] ?? '—') ?></p>
      <p><strong>Job Title:</strong> <?= htmlspecialchars($supervisor['job_title'] ?? '—') ?></p>
      <p><strong>Start Date:</strong> <?= htmlspecialchars($supervisor['start_date'] ?? '—') ?></p>
      <p><strong>Address Line 1:</strong> <?= htmlspecialchars($supervisor['address_line1'] ?? '—') ?></p>
      <p><strong>Town/City:</strong> <?= htmlspecialchars($supervisor['town_city'] ?? '—') ?></p>
      <p><strong>Postcode:</strong> <?= htmlspecialchars($supervisor['postcode'] ?? '—') ?></p>
      <p><strong>Disability Status:</strong> <?= htmlspecialchars($supervisor['disability_status'] ?? '—') ?></p>
      <p><strong>Disability Type:</strong> <?= htmlspecialchars($supervisor['disability_type'] ?? '—') ?></p>
      <p><strong>DBS Status:</strong> <?= htmlspecialchars($supervisor['dbs_status'] ?? '—') ?></p>
      <p><strong>DBS Issue Date:</strong> <?= htmlspecialchars($supervisor['dbs_date'] ?? '—') ?></p>
      <p><strong>DBS Reference:</strong> <?= htmlspecialchars($supervisor['dbs_reference'] ?? '—') ?></p>
      <p><strong>DBS Update Service:</strong>
        <?= isset($supervisor['dbs_update_service']) && $supervisor['dbs_update_service'] ? 'Yes' : 'No' ?>
      </p>

<?php if (in_array($_SESSION['role'], ['superuser', 'admin']) && $userStatus && $userStatus['account_locked']): ?>
  <form method="post" action="unlock_user.php" style="margin-top: 20px;">
    <input type="hidden" name="user_id" value="<?= $supervisor['supervisor_id'] ?>">
    <input type="hidden" name="supervisor_id" value="<?= $supervisor['supervisor_id'] ?>">
    <button type="submit" class="btn-edit">Unlock Account</button>
    <p style="margin-top: 8px; color: #d32f2f;">Account is currently locked after <?= $userStatus['failed_attempts'] ?> failed attempts.</p>
  </form>
<?php endif; ?>

<?php if (in_array($_SESSION['role'], ['superuser', 'admin'])): ?>
  <form method="post" action="reset_password_admin.php" style="margin-top: 30px;">
    <input type="hidden" name="user_id" value="<?= $supervisor['supervisor_id'] ?>">
    <input type="hidden" name="role" value="supervisor">
    <label for="new_password"><strong>Set New Password:</strong></label>
    <input
      type="password"
      name="new_password"
      id="new_password"
      required
      pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$"
      title="Password must be at least 8 characters long and include uppercase, lowercase, number, and special character."
      style="width: 100%; padding: 8px; margin-top: 8px;"
    >
    <button type="submit" class="btn-edit" style="margin-top: 10px;">Update Password</button>
  </form>
<?php endif; ?>

<?php if (isset($_GET['reset']) && $_GET['reset'] === '1'): ?>
  <div class="message success">Password successfully updated.</div>
<?php elseif (isset($_GET['reset']) && $_GET['reset'] === 'weak'): ?>
  <div class="message error">Password does not meet strength requirements.</div>
<?php endif; ?>

      <a href="edit_supervisors.php?supervisor_id=<?= $supervisor['supervisor_id'] ?>" class="btn-edit">✎ Edit Supervisor</a>
      <a href="supervisors.php?view=<?= $supervisor['is_archived'] ? 'archived' : 'active' ?>" class="btn-edit" style="margin-left: 10px;">← Back to List</a>
    </div>

    <div class="curriculum-list">
      <h3>Courses Assigned</h3>
      <?php if (empty($courses)): ?>
        <p><em>No courses assigned.</em></p>
      <?php else: ?>
        <ul>
          <?php foreach ($courses as $c): ?>
            <li><?= htmlspecialchars($c) ?></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <h3>Modules Assigned</h3>
      <?php if (empty($modules)): ?>
        <p><em>No modules assigned.</em></p>
      <?php else: ?>
        <ul>
          <?php foreach ($modules as $m): ?>
            <li><?= htmlspecialchars($m) ?></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>

    <div class="trainee-list">
      <h3>Assigned Trainees</h3>
      <?php if (empty($trainees)): ?>
        <p><em>No trainees assigned.</em></p>
      <?php else: ?>
        <ul>
          <?php foreach ($trainees as $t): ?>
            <li><?= htmlspecialchars($t['first_name'] . ' ' . $t['surname']) ?></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  </div>
</div>
</body>
</html>