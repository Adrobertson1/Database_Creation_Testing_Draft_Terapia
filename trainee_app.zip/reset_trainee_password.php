<?php
require 'auth.php';
require 'db.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin'])) {
    die("Access denied.");
}

$user_id = $_POST['user_id'] ?? '';
$trainee_id = $_POST['trainee_id'] ?? '';
$new_password = $_POST['new_password'] ?? '';

// Password strength checker (same as reset_password.php)
function is_strong_password($password) {
    return strlen($password) >= 8 &&
           preg_match('/[A-Z]/', $password) &&
           preg_match('/[a-z]/', $password) &&
           preg_match('/[0-9]/', $password) &&
           preg_match('/[\W]/', $password);
}

if ($trainee_id && $new_password) {
    if (!is_strong_password($new_password)) {
        header("Location: view_trainee.php?id=" . urlencode($trainee_id) . "&reset=weak");
        exit;
    }

    $hashed = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE trainees SET password = ? WHERE trainee_id = ?");
    $stmt->execute([$hashed, $trainee_id]);

    $audit = $pdo->prepare("
        INSERT INTO audit_log (user_id, role, action_type, action_detail, ip_address, timestamp)
        VALUES (?, ?, 'password_reset', 'Manual password reset by admin', ?, NOW())
    ");
    $audit->execute([
        $_SESSION['user_id'],
        $_SESSION['role'],
        $_SERVER['REMOTE_ADDR']
    ]);

    header("Location: view_trainee.php?id=" . urlencode($trainee_id) . "&reset=1");
    exit;
}
?>