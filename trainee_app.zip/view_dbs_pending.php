<?php require 'auth.php'; ?>
<?php
require 'db.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin', 'staff'])) {
  die("Access denied.");
}

// Trainees
$traineeStmt = $pdo->prepare("
  SELECT 'Trainee' AS user_type, trainee_id AS id, first_name, surname, email, start_date,
         NULL AS dbs_type, dbs_status, dbs_issue_date, dbs_expiry_date
  FROM trainees
  WHERE dbs_status IS NOT NULL AND is_archived = 0
");
$traineeStmt->execute();
$traineeRecords = $traineeStmt->fetchAll(PDO::FETCH_ASSOC);

// Tutors
$tutorStmt = $pdo->prepare("
  SELECT 'Tutor' AS user_type, tutor_id AS id, first_name, surname, email, start_date,
         NULL AS dbs_type, dbs_status, dbs_date AS dbs_issue_date, dbs_expiry_date
  FROM tutors
  WHERE dbs_status IS NOT NULL AND is_archived = 0
");
$tutorStmt->execute();
$tutorRecords = $tutorStmt->fetchAll(PDO::FETCH_ASSOC);

// Supervisors
$supervisorStmt = $pdo->prepare("
  SELECT 'Supervisor' AS user_type, supervisor_id AS id,
         CONCAT_WS(' ', first_name, surname_prefix, surname) AS full_name,
         email, start_date,
         NULL AS dbs_type, dbs_status, dbs_date AS dbs_issue_date, dbs_expiry_date
  FROM supervisors
  WHERE dbs_status IS NOT NULL AND is_archived = 0
");
$supervisorStmt->execute();
$supervisorRaw = $supervisorStmt->fetchAll(PDO::FETCH_ASSOC);
$supervisorRecords = array_map(function($r) {
  return [
    'user_type' => $r['user_type'],
    'id' => $r['id'],
    'first_name' => $r['full_name'],
    'surname' => '',
    'email' => $r['email'],
    'start_date' => $r['start_date'],
    'dbs_type' => $r['dbs_type'],
    'dbs_status' => $r['dbs_status'],
    'dbs_issue_date' => $r['dbs_issue_date'],
    'dbs_expiry_date' => $r['dbs_expiry_date']
  ];
}, $supervisorRaw);

// Staff
$staffStmt = $pdo->prepare("
  SELECT 'Staff' AS user_type, staff_id AS id, first_name, surname, email, start_date,
         NULL AS dbs_type, dbs_status, dbs_date AS dbs_issue_date, NULL AS dbs_expiry_date
  FROM staff
  WHERE dbs_status IS NOT NULL AND is_archived = 0
");
$staffStmt->execute();
$staffRecords = $staffStmt->fetchAll(PDO::FETCH_ASSOC);

// Merge and sort
$records = array_merge($traineeRecords, $tutorRecords, $supervisorRecords, $staffRecords);
usort($records, fn($a, $b) => strcmp($a['first_name'], $b['first_name']));

// CSV export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
  header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename=dbs_pending.csv');
  header('Pragma: no-cache');
  header('Expires: 0');

  $output = fopen('php://output', 'w');
  fputcsv($output, ['User Type', 'Name', 'Email', 'Start Date', 'DBS Status', 'Issue Date', 'Expiry Date', 'Profile Link']);
  foreach ($records as $r) {
    $link = match($r['user_type']) {
      'Tutor' => "view_tutor.php?id={$r['id']}",
      'Supervisor' => "view_supervisor.php?id={$r['id']}",
      'Staff' => "view_staff.php?id={$r['id']}",
      default => "view_trainee.php?id={$r['id']}"
    };
    fputcsv($output, [
      $r['user_type'],
      $r['first_name'] . ' ' . $r['surname'],
      $r['email'],
      $r['start_date'],
      $r['dbs_status'] ?? '—',
      $r['dbs_issue_date'] ?? '—',
      $r['dbs_expiry_date'] ?? '—',
      $link
    ]);
  }
  fclose($output);
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>DBS Records</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .main-content { padding: 40px; max-width: 1200px; margin: auto; }
    .record-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    .record-table th, .record-table td {
      padding: 10px;
      border-bottom: 1px solid #ccc;
    }
    .record-table th {
      background-color: #6a1b9a;
      color: white;
    }
    .btn {
      display: inline-block;
      padding: 8px 16px;
      background-color: #6a1b9a;
      color: white;
      text-decoration: none;
      border-radius: 4px;
      font-weight: bold;
      margin-bottom: 20px;
    }
    .btn:hover {
      background-color: #4a148c;
    }
    .name-link {
      color: #6a1b9a;
      font-weight: bold;
      text-decoration: none;
    }
    .name-link:hover {
      text-decoration: underline;
    }
    .no-results {
      font-style: italic;
      color: #777;
    }
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="dashboard-wrapper">
  <?php include 'sidebar.php'; ?>
  <div class="main-content">
    <h2>DBS Records (All Users)</h2>

    <a href="view_dbs_pending.php?export=csv" class="btn">Export CSV</a>

    <?php if (count($records) === 0): ?>
      <p class="no-results">No DBS records found.</p>
    <?php else: ?>
      <table class="record-table">
        <thead>
          <tr>
            <th>User Type</th>
            <th>Name</th>
            <th>Email</th>
            <th>Start Date</th>
            <th>Status</th>
            <th>Issue Date</th>
            <th>Expiry Date</th>
            <th>View</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($records as $r): ?>
            <?php
              $link = match($r['user_type']) {
                'Tutor' => "view_tutor.php?id={$r['id']}",
                'Supervisor' => "view_supervisor.php?id={$r['id']}",
                'Staff' => "view_staff.php?id={$r['id']}",
                default => "view_trainee.php?id={$r['id']}"
              };
            ?>
            <tr>
              <td><?= htmlspecialchars($r['user_type']) ?></td>
              <td>
                <a href="<?= $link ?>" class="name-link" target="_blank">
                  <?= htmlspecialchars($r['first_name'] . ' ' . $r['surname']) ?>
                </a>
              </td>
              <td><?= htmlspecialchars($r['email']) ?></td>
              <td><?= htmlspecialchars($r['start_date']) ?></td>
              <td><?= htmlspecialchars($r['dbs_status'] ?? '—') ?></td>
              <td><?= htmlspecialchars($r['dbs_issue_date'] ?? '—') ?></td>
              <td><?= htmlspecialchars($r['dbs_expiry_date'] ?? '—') ?></td>
              <td><a href="<?= $link ?>" class="btn" target="_blank">View</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
</body>
</html>