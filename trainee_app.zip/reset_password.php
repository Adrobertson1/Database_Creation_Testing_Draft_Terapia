<?php
session_start();
require 'db.php';

$error = '';
$debug = [];
$token = $_GET['token'] ?? '';
$valid = false;

if ($token) {
    $stmt = $pdo->prepare("
        SELECT * FROM password_resets
        WHERE token = ? AND expires_at > NOW()
        LIMIT 1
    ");
    $stmt->execute([$token]);
    $reset = $stmt->fetch();

    if ($reset) {
        $debug[] = "✅ Token found → expires_at: {$reset['expires_at']}";
        $valid = true;
        $email = $reset['email'];
        $role = $reset['role'];
        $user_id = $reset['user_id'];
        $debug[] = "🔍 Reset record loaded → role: $role, user_id: $user_id";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM password_resets WHERE token = ?");
        $stmt->execute([$token]);
        $raw = $stmt->fetch();
        if ($raw) {
            $debug[] = "⏳ Token exists but expired → expires_at: {$raw['expires_at']}";
        } else {
            $debug[] = "❌ Token not found in password_resets table.";
        }
    }
}

function updatePassword($pdo, $role, $user_id, $new_hash, &$debug) {
    $tables = [
        'users'       => ['id' => 'user_id',       'field' => 'password'],
        'staff'       => ['id' => 'staff_id',      'field' => 'password'],
        'trainees'    => ['id' => 'trainee_id',    'field' => 'password'],
        'tutors'      => ['id' => 'tutor_id',      'field' => 'password'],
        'supervisors' => ['id' => 'supervisor_id', 'field' => 'password']
    ];

    $debug[] = "🔍 Role: $role";
    $debug[] = "🔍 User ID: $user_id";

    foreach ($tables as $table => $map) {
        $debug[] = "🔍 Checking table: $table, ID field: {$map['id']}";

        if (
            $role === $table ||
            ($role === 'trainee' && $table === 'trainees') ||
            ($role === 'tutor' && $table === 'tutors') ||
            ($role === 'supervisor' && $table === 'supervisors') ||
            ($role === 'superuser' && $table === 'staff') ||  // patched: superuser → staff
            ($role === 'staff' && $table === 'staff')
        ) {
            $stmt = $pdo->prepare("
                UPDATE $table SET {$map['field']} = ?
                WHERE {$map['id']} = ?
            ");
            $stmt->execute([$new_hash, $user_id]);

            $affected = $stmt->rowCount();
            $debug[] = "✅ Matched table: $table → Rows affected: $affected";

            return $affected > 0;
        }
    }

    $debug[] = "❌ No matching table found for role: $role";
    return false;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $valid) {
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    if (strlen($password) < 8 || !preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $error = "Password must be at least 8 characters, include a number and an uppercase letter.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $debug[] = "🔐 New hash: $hash";

        if (updatePassword($pdo, $role, $user_id, $hash, $debug)) {
            $stmt = $pdo->prepare("DELETE FROM password_resets WHERE token = ?");
            $stmt->execute([$token]);
            header("Location: reset_success.php?audit=ok");
            exit;
        } else {
            $error = "Failed to update password. Please contact support.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Terapia | Reset Password</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background: #E6D6EC;
      color: #000;
    }
    .reset-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin-top: 60px;
    }
    .logo {
      width: 120px;
      margin-bottom: 20px;
    }
    .reset-box {
      background: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 400px;
      text-align: center;
    }
    .reset-box h2 {
      color: #850069;
      font-family: 'Josefin Sans', sans-serif;
      margin-bottom: 20px;
    }
    .reset-box label {
      display: block;
      margin-top: 15px;
      font-weight: bold;
      text-align: left;
    }
    .reset-box input {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 16px;
    }
    .reset-box button {
      margin-top: 20px;
      padding: 12px;
      background-color: #850069;
      color: white;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      width: 100%;
      font-size: 18px;
    }
    .reset-box button:hover {
      background-color: #BB9DC6;
    }
    .message.error {
      margin-top: 15px;
      color: #d32f2f;
      font-weight: bold;
    }
    .note {
      font-size: 14px;
      color: #555;
      margin-top: 10px;
      text-align: left;
    }
    .debug-output {
      margin-top: 20px;
      text-align: left;
      font-size: 13px;
      background: #f9f9f9;
      padding: 10px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }
    .back-link {
      margin-top: 20px;
      display: block;
      text-align: center;
      color: #850069;
      font-weight: bold;
      text-decoration: none;
    }
    .back-link:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
<div class="reset-wrapper">
  <img src="assets/logo.png" alt="Terapia Logo" class="logo">

  <div class="reset-box">
    <h2>Reset Your Password</h2>

    <?php if (!$valid): ?>
      <div class="message error">This reset link is invalid or has expired.</div>
    <?php elseif ($error): ?>
      <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($valid): ?>
      <form method="post">
        <label for="password">New Password:</label>
        <input type="password" name="password" id="password" required>

        <label for="confirm">Confirm Password:</label>
        <input type="password" name="confirm" id="confirm" required>

        <div class="note">Password must be at least 8 characters, include a number and an uppercase letter.</div>

        <button type="submit">Reset Password</button>
      </form>
    <?php endif; ?>

    <?php if (!empty($debug)): ?>
      <div class="debug-output">
        <strong>Debug Output:</strong>
        <ul>
          <?php foreach ($debug as $line): ?>
            <li><?= htmlspecialchars($line) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <a href="login.php" class="back-link">← Back to Login</a>
  </div>
</div>
</body>
</html>