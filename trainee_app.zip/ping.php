<?php
require 'auth.php';
echo json_encode(['status' => 'ok', 'timestamp' => time()]);