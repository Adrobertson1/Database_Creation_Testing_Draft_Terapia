<?php require 'auth.php'; ?>
<?php
require 'db.php';

if (!in_array($_SESSION['role'], ['admin', 'superuser'])) {
  die("Access denied.");
}

$staffId = $_GET['user_id'] ?? '';
if (!$staffId) {
  die("No staff ID provided.");
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $newPassword = $_POST['new_password'] ?? '';
  $confirmPassword = $_POST['confirm_password'] ?? '';

  if (empty($newPassword) || empty($confirmPassword)) {
    $error = "Both password fields are required.";
  } elseif ($newPassword !== $confirmPassword) {
    $error = "Passwords do not match.";
  } elseif (strlen($newPassword) < 8) {
    $error = "Password must be at least 8 characters.";
  } else {
    try {
      $stmt = $pdo->prepare("SELECT staff_id, email FROM staff WHERE staff_id = :id");
      $stmt->execute(['id' => $staffId]);
      $staff = $stmt->fetch();

      if (!$staff) {
        $error = "Staff member not found.";
      } else {
        $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
        $update = $pdo->prepare("UPDATE staff SET password = :pw WHERE staff_id = :id");
        $update->execute(['pw' => $hashed, 'id' => $staffId]);

        // Audit log
        $audit = $pdo->prepare("
          INSERT INTO audit_log (
            user_id, role, action_type, table_name, record_id, staff_id,
            action_detail, ip_address, action
          ) VALUES (
            :user_id, :role, :action_type, :table_name, :record_id, :staff_id,
            :action_detail, :ip_address, :action
          )
        ");
        $audit->execute([
          'user_id' => $_SESSION['user_id'],
          'role' => $_SESSION['role'],
          'action_type' => 'password_reset',
          'table_name' => 'staff',
          'record_id' => $staffId,
          'staff_id' => $staffId,
          'action_detail' => 'Password reset by admin',
          'ip_address' => $_SERVER['REMOTE_ADDR'],
          'action' => 'update'
        ]);

        // Admin password reset log
        $log = $pdo->prepare("
          INSERT INTO admin_password_resets (staff_id, reset_by, ip_address, reason)
          VALUES (:staff_id, :reset_by, :ip, :reason)
        ");
        $log->execute([
          'staff_id' => $staffId,
          'reset_by' => $_SESSION['user_id'],
          'ip' => $_SERVER['REMOTE_ADDR'],
          'reason' => 'Manual reset via admin panel'
        ]);

        header("Location: view_staff.php?id=$staffId&reset=1");
        exit;
      }
    } catch (PDOException $e) {
      $error = "Database error: " . htmlspecialchars($e->getMessage());
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reset Staff Password</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .form-container {
      max-width: 500px;
      margin: 40px auto;
      padding: 20px;
      border: 1px solid #ccc;
      border-radius: 6px;
      background: #f9f9f9;
    }
    .form-container h2 {
      margin-bottom: 20px;
    }
    .form-container label {
      display: block;
      margin-top: 15px;
    }
    .form-container input {
      width: 100%;
      padding: 8px;
      margin-top: 5px;
    }
    .form-container button {
      margin-top: 20px;
      padding: 10px 16px;
      background-color: #6a1b9a;
      color: white;
      border: none;
      border-radius: 4px;
      font-weight: bold;
    }
    .form-container .message {
      margin-top: 15px;
      font-weight: bold;
    }
    .success { color: green; }
    .error { color: red; }
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="dashboard-wrapper">
  <?php include 'sidebar.php'; ?>
  <div class="main-content">
    <div class="form-container">
      <h2>Reset Staff Password</h2>

      <?php if (isset($error)): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="post">
        <input type="hidden" name="user_id" value="<?= htmlspecialchars($staffId) ?>">

        <label for="new_password">New Password:</label>
        <input
          type="password"
          name="new_password"
          id="new_password"
          required
          pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$"
          title="Must be 8+ characters, include uppercase, lowercase, number, and special character."
        >

        <label for="confirm_password">Confirm Password:</label>
        <input
          type="password"
          name="confirm_password"
          id="confirm_password"
          required
        >

        <button type="submit">Update Password</button>
      </form>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>
</body>
</html>