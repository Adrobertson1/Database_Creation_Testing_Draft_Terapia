<?php
return [
    'SMTP_HOST'       => 'smtp.office365.com',
    'SMTP_PORT'       => 587,
    'SMTP_USER'       => 'alex.robertson-testing@terapia.co.uk',
    'SMTP_PASS'       => 'R0b3rts0n25!',
    'SMTP_SECURE'     => 'tls',
    'RESET_URL_BASE'  => 'https://unfoully-binaural-lino.ngrok-free.app/trainee_app'
];