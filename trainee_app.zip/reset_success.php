<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Terapia | Password Reset Successful</title>
  <link rel="stylesheet" href="style.css">
  <meta http-equiv="refresh" content="8;url=login.php">
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background: #E6D6EC;
      color: #000;
    }
    .success-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin-top: 60px;
    }
    .logo {
      width: 120px;
      margin-bottom: 20px;
    }
    .success-box {
      background: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 400px;
      text-align: center;
    }
    .success-box h2 {
      color: #388e3c;
      font-family: 'Josefin Sans', sans-serif;
      margin-bottom: 20px;
    }
    .success-box p {
      font-size: 16px;
      color: #333;
      margin-bottom: 10px;
    }
    .countdown {
      font-size: 14px;
      color: #555;
      margin-top: 10px;
    }
    .back-link {
      margin-top: 20px;
      display: block;
      text-align: center;
      color: #850069;
      font-weight: bold;
      text-decoration: none;
    }
    .back-link:hover {
      text-decoration: underline;
    }
  </style>
  <script>
    let seconds = 8;
    function updateCountdown() {
      const el = document.getElementById('countdown');
      if (seconds > 0) {
        el.textContent = "Redirecting to login in " + seconds + " seconds...";
        seconds--;
        setTimeout(updateCountdown, 1000);
      }
    }
    window.onload = updateCountdown;
  </script>
</head>
<body>
<div class="success-wrapper">
  <img src="assets/logo.png" alt="Terapia Logo" class="logo">

  <div class="success-box">
    <h2>Password Reset Successful</h2>
    <p>Your password has been updated.</p>
    <p>You will be redirected to the login page shortly.</p>
    <div class="countdown" id="countdown">Redirecting to login in 8 seconds...</div>
    <a href="login.php" class="back-link">← Back to Login</a>
  </div>
</div>
</body>
</html>