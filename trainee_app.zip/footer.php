<!-- footer.php -->
<footer style="text-align:center; padding:20px; font-size:14px; color:#666;">
  &copy; <?= date('Y') ?> Terapia. All rights reserved.
</footer>