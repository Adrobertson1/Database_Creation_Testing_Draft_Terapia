<?php require 'auth.php'; ?>
<?php
require 'db.php';

if (!in_array($_SESSION['role'], ['superuser', 'admin'])) {
  die("Access denied.");
}

$staff_id = $_GET['id'] ?? null;
if (!$staff_id) {
  die("No staff ID provided.");
}

$stmt = $pdo->prepare("SELECT * FROM staff WHERE staff_id = ?");
$stmt->execute([$staff_id]);
$staff = $stmt->fetch();

if (!$staff) {
  die("Staff member not found.");
}

$photoPath = '';
if (!empty($staff['profile_image'])) {
  $photoPath = 'uploads/' . basename($staff['profile_image']);
  if (!file_exists($photoPath)) {
    $photoPath = '';
  }
}

$statusLabel = $staff['is_archived'] ? 'Archived' : 'Active';
$statusColor = $staff['is_archived'] ? '#d32f2f' : '#4CAF50';

// Check account lock status
$userStatusStmt = $pdo->prepare("SELECT account_locked, failed_attempts FROM users WHERE user_id = ?");
$userStatusStmt->execute([$staff['staff_id']]);
$userStatus = $userStatusStmt->fetch();

// Fetch unlock audit history
$auditStmt = $pdo->prepare("
  SELECT timestamp, user_id, ip_address, action_detail
  FROM audit_log
  WHERE staff_id = :staff_id AND action_type = 'account_unlock'
  ORDER BY timestamp DESC
  LIMIT 10
");
$auditStmt->execute(['staff_id' => $staff_id]);
$unlockEvents = $auditStmt->fetchAll();

// Fetch admin password reset history with full name resolution
$resetStmt = $pdo->prepare("
  SELECT r.reset_at, r.reset_by, r.ip_address, r.reason,
         s.first_name, s.surname
  FROM admin_password_resets r
  LEFT JOIN staff s ON r.reset_by = s.staff_id
  WHERE r.staff_id = :staff_id
  ORDER BY r.reset_at DESC
  LIMIT 10
");
$resetStmt->execute(['staff_id' => $staff_id]);
$resetEvents = $resetStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>View Staff Member</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .profile-box {
      background: #f9f9f9;
      padding: 20px;
      border-radius: 8px;
      max-width: 600px;
      margin-bottom: 30px;
      border: 1px solid #ccc;
    }
    .profile-label {
      font-weight: bold;
      display: inline-block;
      width: 150px;
    }
    .profile-field {
      margin-bottom: 10px;
    }
    .profile-photo img {
      max-width: 120px;
      border-radius: 8px;
      border: 1px solid #ccc;
    }
    .btn-back, .btn-edit, .btn-reset {
      margin-top: 20px;
      display: inline-block;
      padding: 8px 16px;
      background-color: #850069;
      color: #fff;
      text-decoration: none;
      border-radius: 4px;
      margin-right: 10px;
    }
    .btn-back:hover, .btn-edit:hover, .btn-reset:hover {
      background-color: #BB9DC6;
    }
    .status-tag {
      display: inline-block;
      padding: 4px 10px;
      border-radius: 4px;
      font-weight: bold;
      color: white;
      background-color: <?= $statusColor ?>;
      margin-left: 10px;
      font-size: 0.9em;
    }
    .message.success {
      margin-top: 15px;
      color: #2e7d32;
      font-weight: bold;
    }
    .message.error {
      margin-top: 15px;
      color: #d32f2f;
      font-weight: bold;
    }
    .audit-log {
      margin-top: 30px;
      padding: 15px;
      background: #f1f1f1;
      border-radius: 6px;
      border: 1px solid #ccc;
    }
    .audit-log h4 {
      margin-bottom: 10px;
    }
    .audit-log ul {
      list-style: disc;
      padding-left: 20px;
    }
    .audit-log li {
      margin-bottom: 6px;
    }
  </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="dashboard-wrapper">
  <?php include 'sidebar.php'; ?>
  <div class="main-content">
    <h2>View Staff Member</h2>

    <div class="profile-box">
      <h3>
        <?= htmlspecialchars($staff['first_name'] . ' ' . $staff['surname']) ?>
        <span class="status-tag"><?= $statusLabel ?></span>
      </h3>

      <div class="profile-photo">
        <?php if ($photoPath): ?>
          <img src="<?= $photoPath ?>" alt="Staff Photo">
        <?php else: ?>
          <em>No photo available.</em>
        <?php endif; ?>
      </div>

      <div class="profile-field"><span class="profile-label">Email:</span> <?= htmlspecialchars($staff['email'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Telephone:</span> <?= htmlspecialchars($staff['telephone'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Job Title:</span> <?= htmlspecialchars($staff['job_title'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Start Date:</span> <?= htmlspecialchars($staff['start_date'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">DBS Status:</span> <?= htmlspecialchars($staff['dbs_status'] ?? '-') ?></div>
      <div class="profile-field"><span class="profile-label">Role:</span> <?= htmlspecialchars($staff['role'] ?? 'Staff') ?></div>

      <?php if (in_array($_SESSION['role'], ['superuser', 'admin']) && $userStatus && $userStatus['account_locked']): ?>
        <form method="post" action="unlock_user.php" style="margin-top: 20px;" onsubmit="return confirm('Are you sure you want to unlock this account?')">
          <input type="hidden" name="user_id" value="<?= $staff['staff_id'] ?>">
          <input type="hidden" name="staff_id" value="<?= $staff['staff_id'] ?>">
          <button type="submit" class="btn">Unlock Account</button>
          <p style="margin-top: 8px; color: #d32f2f;">Account is currently locked after <?= $userStatus['failed_attempts'] ?> failed attempts.</p>
        </form>
      <?php endif; ?>

      <?php if (in_array($_SESSION['role'], ['superuser', 'admin'])): ?>
        <a href="reset_password_admin.php?user_id=<?= urlencode($staff['staff_id']) ?>" class="btn-reset">🔒 Reset Password</a>
      <?php endif; ?>

      <?php if (isset($_GET['reset']) && $_GET['reset'] === '1'): ?>
        <div class="message success">Password successfully updated.</div>
      <?php elseif (isset($_GET['reset']) && $_GET['reset'] === 'weak'): ?>
        <div class="message error">Password does not meet strength requirements.</div>
      <?php endif; ?>

      <a href="staff.php?view=<?= $staff['is_archived'] ? 'archived' : 'active' ?>" class="btn-back">← Back to List</a>
      <a href="edit_staff.php?staff_id=<?= urlencode($staff['staff_id']) ?>" class="btn-edit">✏️ Edit Staff</a>
    </div>

    <div class="audit-log">
      <h4>Recent Unlock Activity</h4>
      <?php if ($unlockEvents): ?>
        <ul>
          <?php foreach ($unlockEvents as $event): ?>
            <li>
              <?= htmlspecialchars($event['timestamp']) ?> —
              <?= htmlspecialchars($event['action_detail']) ?> by user ID <?= $event['user_id'] ?>
              (IP: <?= htmlspecialchars($event['ip_address']) ?>)
            </li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <p>No unlock activity recorded.</p>
      <?php endif; ?>
    </div>

    <div class="audit-log">
      <h4>Recent Password Reset Activity</h4>
      <?php if ($resetEvents): ?>
        <ul>
          <?php foreach ($resetEvents as $event): ?>
            <li>
              <?= htmlspecialchars($event['reset_at']) ?> —
              Reset by <?= $event['first_name'] ? htmlspecialchars($event['first_name'] . ' ' . $event['surname']) : 'user ID ' . $event['reset_by'] ?>
              (IP: <?= htmlspecialchars($event['ip_address']) ?>)
              <?php if (!empty($event['reason'])): ?>
                — <?= htmlspecialchars($event['reason']) ?>
              <?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <p>No admin password resets recorded.</p>
      <?php endif; ?>
    </div>

  </div>
</div>
</body>
</html>